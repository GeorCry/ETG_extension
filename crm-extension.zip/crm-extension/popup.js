// CRM ETG Tools — Popup v3.0

let allTickets = [];

// ─── Init ───
document.addEventListener('DOMContentLoaded', () => {
    refreshTickets();
    loadNotes();
    loadStats();
    loadSettings();
});

// ─── Tabs ───
function showTab(name) {
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    document.getElementById('tab-' + name).classList.add('active');
    event.target.classList.add('active');
    if (name === 'search') document.getElementById('search-input').focus();
}

// ─── TICKETS TAB ───
function refreshTickets() {
    chrome.runtime.sendMessage({ type: 'get_ticket_tabs' }, (res) => {
        allTickets = res?.tickets || [];
        document.getElementById('tab-count').innerText = `${allTickets.length} tabs`;
        renderTicketList();
    });
}

function renderTicketList() {
    const list = document.getElementById('ticket-list');
    if (allTickets.length === 0) {
        list.innerHTML = '<div class="empty">No ticket tabs open</div>';
        return;
    }
    list.innerHTML = '';
    allTickets.forEach(t => {
        const storageKey = 'autoprolong_active_/tickets/' + t.id + '/';
        const isOn = localStorage.getItem(storageKey) === 'true';
        const item = document.createElement('div');
        item.className = 'ticket-item';
        item.innerHTML = `
            <div class="ticket-id">#${t.id}</div>
            <div class="ticket-title">${t.title?.replace('CRM', '').replace('–','').trim() || '—'}</div>
            <div class="ticket-prolong ${isOn ? 'prolong-on' : 'prolong-off'}">${isOn ? '⏱ ON' : 'OFF'}</div>
        `;
        item.onclick = () => focusTab(t.tabId);
        list.appendChild(item);
    });
}

function focusTab(tabId) {
    chrome.runtime.sendMessage({ type: 'focus_tab', tabId });
}

function closeDupes() {
    setStatus('tickets-status', 'Closing duplicates...', 'info');
    chrome.runtime.sendMessage({ type: 'close_duplicate_tabs' }, (res) => {
        const closed = res?.closed || 0;
        setStatus('tickets-status', `✅ Closed ${closed} duplicate tab${closed !== 1 ? 's' : ''}`, 'ok');
        setTimeout(refreshTickets, 500);
    });
}

// ─── BULK TAB ───
function bulkHandover() {
    setStatus('bulk-status', '🔁 Running Handover on all tabs...', 'info');
    chrome.runtime.sendMessage({ type: 'bulk_handover' }, (res) => {
        const done = res?.done || 0;
        setStatus('bulk-status', `✅ Handover sent to ${done} tabs`, 'ok');
    });
}

function loadSettings() {
    const autoOpen = localStorage.getItem('crm_auto_open') === 'true';
    const autoReload = localStorage.getItem('crm_auto_reload_on') === 'true';
    const notify = localStorage.getItem('crm_notify') === 'true';
    document.getElementById('toggle-auto-open').checked = autoOpen;
    document.getElementById('toggle-auto-reload').checked = autoReload;
    document.getElementById('toggle-notify').checked = notify;
    document.getElementById('auto-open-min').value = localStorage.getItem('crm_auto_timer_min') || '5';
    document.getElementById('auto-reload-min').value = localStorage.getItem('crm_auto_reload_min') || '3';
}

function toggleAutoOpen() {
    const on = document.getElementById('toggle-auto-open').checked;
    localStorage.setItem('crm_auto_open', on ? 'true' : '');
    setStatus('bulk-status', on ? '✅ Auto open enabled' : '⏸ Auto open disabled', on ? 'ok' : '');
}

function toggleAutoReload() {
    const on = document.getElementById('toggle-auto-reload').checked;
    localStorage.setItem('crm_auto_reload_on', on ? 'true' : '');
    setStatus('bulk-status', on ? '✅ Auto reload enabled' : '⏸ Auto reload disabled', on ? 'ok' : '');
}

function toggleNotify() {
    const on = document.getElementById('toggle-notify').checked;
    localStorage.setItem('crm_notify', on ? 'true' : '');
    if (on) {
        chrome.runtime.sendMessage({ type: 'notify', title: 'CRM ETG Tools', message: 'Notifications enabled! ✅' });
    }
    setStatus('bulk-status', on ? '✅ Notifications enabled' : '⏸ Notifications disabled', on ? 'ok' : '');
}

function saveAutoOpenMin() {
    localStorage.setItem('crm_auto_timer_min', document.getElementById('auto-open-min').value);
}

function saveAutoReloadMin() {
    localStorage.setItem('crm_auto_reload_min', document.getElementById('auto-reload-min').value);
}

// ─── NOTES TAB ───
function getNotes() {
    try { return JSON.parse(localStorage.getItem('crm_notes') || '[]'); }
    catch { return []; }
}

function saveNotes(notes) {
    localStorage.setItem('crm_notes', JSON.stringify(notes));
}

function loadNotes() {
    const notes = getNotes();
    const list = document.getElementById('notes-list');
    if (notes.length === 0) {
        list.innerHTML = '<div class="empty">No notes yet</div>';
        return;
    }
    list.innerHTML = '';
    notes.forEach((n, i) => {
        const el = document.createElement('div');
        el.className = 'note-item';
        el.innerHTML = `
            <div class="note-header">
                <span class="note-id">#${n.ticketId}</span>
                <button class="note-del" onclick="deleteNote(${i})">✕</button>
            </div>
            <div class="note-text">${escHtml(n.text)}</div>
        `;
        list.appendChild(el);
    });
}

function addNote() {
    const ticketId = document.getElementById('note-ticket-id').value.trim();
    const text = document.getElementById('note-text').value.trim();
    if (!ticketId || !text) return;
    const notes = getNotes();
    notes.unshift({ ticketId, text, ts: Date.now() });
    saveNotes(notes);
    document.getElementById('note-ticket-id').value = '';
    document.getElementById('note-text').value = '';
    loadNotes();
}

function deleteNote(i) {
    const notes = getNotes();
    notes.splice(i, 1);
    saveNotes(notes);
    loadNotes();
}

// ─── STATS TAB ───
function getStats() {
    try { return JSON.parse(localStorage.getItem('crm_prolong_stats') || '{"total":0,"today":0,"todayDate":"","byReason":{}}'); }
    catch { return { total: 0, today: 0, todayDate: '', byReason: {} }; }
}

function loadStats() {
    const stats = getStats();
    const today = new Date().toDateString();
    if (stats.todayDate !== today) { stats.today = 0; stats.todayDate = today; }

    document.getElementById('stat-total').innerText = stats.total;
    document.getElementById('stat-today').innerText = stats.today;

    const byReason = document.getElementById('stat-by-reason');
    byReason.innerHTML = '';
    const reasonColors = { tpp: '#6c5ce7', client: '#0984e3', hotel: '#00b894', technical_problem: '#e17055' };
    const reasonLabels = { tpp: 'TPP', client: 'Client', hotel: 'Hotel', technical_problem: 'Technical problem' };
    Object.entries(stats.byReason || {}).forEach(([key, count]) => {
        const color = reasonColors[key] || '#636e72';
        const label = reasonLabels[key] || key;
        const row = document.createElement('div');
        row.style.cssText = 'display:flex;align-items:center;gap:8px;padding:4px 0;';
        row.innerHTML = `
            <div style="width:10px;height:10px;border-radius:3px;background:${color};flex-shrink:0;"></div>
            <div style="flex:1;color:#b2bec3;font-size:11px;">${label}</div>
            <div style="font-weight:700;color:#e2e8f0;font-size:12px;">${count}</div>
        `;
        byReason.appendChild(row);
    });
    if (Object.keys(stats.byReason || {}).length === 0) {
        byReason.innerHTML = '<div class="empty">No data yet</div>';
    }
}

function resetStats() {
    localStorage.removeItem('crm_prolong_stats');
    loadStats();
}

// ─── SEARCH TAB ───
function doSearch() {
    const q = document.getElementById('search-input').value.toLowerCase().trim();
    const results = document.getElementById('search-results');
    if (!q) { results.innerHTML = '<div class="empty">Type to search...</div>'; return; }

    const matches = allTickets.filter(t =>
        t.id.includes(q) || t.title?.toLowerCase().includes(q)
    );

    if (matches.length === 0) {
        results.innerHTML = '<div class="empty">No matches</div>';
        return;
    }

    results.innerHTML = '';
    matches.forEach(t => {
        const el = document.createElement('div');
        el.className = 'search-result';
        el.innerHTML = `
            <div style="color:var(--accent3);font-weight:700;font-size:11px;min-width:70px;">#${t.id}</div>
            <div style="flex:1;font-size:10px;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">${t.title || '—'}</div>
        `;
        el.onclick = () => focusTab(t.tabId);
        results.appendChild(el);
    });
}

// ─── Helpers ───
function setStatus(id, text, type = '') {
    const el = document.getElementById(id);
    if (!el) return;
    el.innerText = text;
    el.className = 'status' + (type ? ' ' + type : '');
}

function escHtml(str) {
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
