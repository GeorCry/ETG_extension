(function () {
    'use strict';

    const wait = (ms) => new Promise(r => setTimeout(r, ms));

    // ─────────────────────────────────────────
    // SHARED — BroadcastChannel
    // ─────────────────────────────────────────
    const channel = new BroadcastChannel('crm_tickets');

    // ─────────────────────────────────────────
    // HELPERS
    // ─────────────────────────────────────────
    function getHandoverPoolTestId() {
        const shift = localStorage.getItem('crm_handover_shift') || 'day';
        return shift === 'night'
            ? 'select_option_incidents_handover_night'
            : 'select_option_incidents_handover_day';
    }

    function fireClick(el) {
        ['mouseover','mousedown','mouseup','click'].forEach(t =>
            el.dispatchEvent(new MouseEvent(t, { bubbles: true })));
    }

    function typeInto(input, text) {
        const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
        setter?.call(input, text);
        input.dispatchEvent(new Event('input', { bubbles: true }));
    }

    async function waitForEl(selector, timeout = 5000) {
        const start = Date.now();
        while (Date.now() - start < timeout) {
            const el = document.querySelector(selector);
            if (el) return el;
            await wait(100);
        }
        return null;
    }

    async function setReactSelect(inputTestId, searchText, optionTestId) {
        const input = document.querySelector(`[data-testid="${inputTestId}"]`);
        if (!input) return false;
        input.focus(); input.click();
        await wait(200);
        typeInto(input, searchText);
        const option = await waitForEl(`[data-testid="${optionTestId}"]`);
        if (!option) return false;
        fireClick(option);
        return true;
    }

    async function clickSave() {
        const start = Date.now();
        while (Date.now() - start < 5000) {
            const btn = [...document.querySelectorAll('button')]
                .find(b => b.innerText?.trim().toLowerCase() === 'save');
            if (btn) { btn.click(); return true; }
            await wait(100);
        }
        return false;
    }

    // ─────────────────────────────────────────
    // NAVIGATION WATCHER
    // ─────────────────────────────────────────
    let lastUrl = location.href;
    let listUIInitialized = false;

    function onUrlChange(newUrl) {
        lastUrl = newUrl;
        document.getElementById('crm-open-tickets-ui')?.remove();
        document.getElementById('crm-sidebar')?.remove();
        document.getElementById('crm-sidebar-tab')?.remove();
        if (autoOpenTimer) { clearInterval(autoOpenTimer); autoOpenTimer = null; }
        if (autoReloadTimer) { clearInterval(autoReloadTimer); autoReloadTimer = null; }
        listUIInitialized = false;

        if (newUrl.match(/\/tickets\/\d+/)) setTimeout(initTicketPage, 1500);
        else if (newUrl.includes('/tickets')) setTimeout(initListPage, 1500);
    }

    const _push = history.pushState.bind(history);
    history.pushState = function (...a) {
        _push(...a);
        setTimeout(() => { if (location.href !== lastUrl) onUrlChange(location.href); }, 100);
    };
    window.addEventListener('popstate', () => {
        setTimeout(() => { if (location.href !== lastUrl) onUrlChange(location.href); }, 100);
    });
    setInterval(() => { if (location.href !== lastUrl) onUrlChange(location.href); }, 500);

    // ─────────────────────────────────────────
    // INIT — decide page type
    // ─────────────────────────────────────────
    if (location.href.match(/\/tickets\/\d+/)) {
        setTimeout(initTicketPage, 2000);
    } else if (location.href.includes('/tickets')) {
        setTimeout(initListPage, 2000);
    }

    // ─────────────────────────────────────────
    // ══════════════════════════════════════════
    // TICKET PAGE
    // ══════════════════════════════════════════
    // ─────────────────────────────────────────

    function getTicketId() {
        return location.pathname.match(/\/tickets\/(\d+)\//)?.[1] || '';
    }
    function storageKey(suffix) { return suffix + '_' + location.pathname; }
    function getSavedReason() { return localStorage.getItem(storageKey('prolong_reason')) || 'select_option_tpp'; }
    function getProlongCount() { return parseInt(localStorage.getItem(storageKey('prolong_count')) || '0'); }
    function incProlongCount() {
        const c = getProlongCount() + 1;
        localStorage.setItem(storageKey('prolong_count'), c);
        const el = document.getElementById('prolong-counter');
        if (el) el.innerText = `🔢 Prolonged: ${c}x`;
    }

    const PROLONG_REASONS = [
        { label: 'TPP',              testid: 'select_option_tpp',              color: '#6c5ce7' },
        { label: 'Client',           testid: 'select_option_client',           color: '#0984e3' },
        { label: 'Hotel',            testid: 'select_option_hotel',            color: '#00b894' },
        { label: 'Technical problem',testid: 'select_option_technical_problem',color: '#e17055' },
    ];

    // ── Title flash ──
    let titleFlashTimer = null;
    let originalTitle = document.title;

    function getBaseTitle() {
        const id = getTicketId();
        return id ? `Ticket#${id}` : (originalTitle || 'CRM');
    }

    function getPriorityEmoji() {
        const el = [...document.querySelectorAll('div,span')]
            .find(e => e.children.length === 0 && ['Urgent','High','Normal','Low'].includes(e.innerText?.trim()));
        return { Urgent:'🔴', High:'🟠', Normal:'🟡', Low:'🟢' }[el?.innerText?.trim()] || '';
    }

    function startTitleFlash(emoji = '⏱') {
        stopTitleFlash();
        let state = false;
        const base = getBaseTitle();
        titleFlashTimer = setInterval(() => {
            document.title = state ? `${emoji} ${base}` : base;
            state = !state;
        }, 1000);
    }

    function stopTitleFlash() {
        if (titleFlashTimer) { clearInterval(titleFlashTimer); titleFlashTimer = null; }
        document.title = getBaseTitle();
    }

    function flashSuccess(reason) {
        stopTitleFlash();
        const base = getBaseTitle();
        let s = false;
        const t = setInterval(() => { document.title = s ? `✅ ${base}` : base; s = !s; }, 500);
        setTimeout(() => { clearInterval(t); startTitleFlash(); }, 5000);
    }

    // ── Auto prolong state ──
    let autoActive = false;
    let autoCheckTimer = null;
    let prolongRunning = false;

    // ── Custom prolong state ──
    let customActive = false;
    let customTimer = null;
    let customCountdownTimer = null;
    let customNextFireAt = null;

    // ── Prolongation core ──
    function findProlongBtn() {
        return [...document.querySelectorAll('button')]
            .find(b => b.innerText?.trim() === 'Prolongation' && !b.disabled);
    }

    async function doProlongation() {
        if (prolongRunning) return false;
        prolongRunning = true;

        try {
            const alreadyOpen = document.querySelector('[data-testid="select_input_prolongation_reason"]');
            if (!alreadyOpen) {
                const btn = findProlongBtn();
                if (!btn) { prolongRunning = false; return false; }
                btn.click();
                await wait(1000);
            }

            let input = null;
            for (let i = 0; i < 15; i++) {
                input = document.querySelector('[data-testid="select_input_prolongation_reason"]');
                if (input) break;
                await wait(200);
            }
            if (!input) { prolongRunning = false; return false; }

            input.focus(); input.click();
            await wait(300);

            const reasonTestId = getSavedReason();
            const reasonLabel = PROLONG_REASONS.find(r => r.testid === reasonTestId)?.label || 'TPP';
            typeInto(input, reasonLabel);
            await wait(800);

            for (let i = 0; i < 15; i++) {
                const opt = document.querySelector(`[data-testid="${reasonTestId}"]`);
                if (opt) {
                    ['mousedown','mouseup','click'].forEach(t =>
                        opt.dispatchEvent(new MouseEvent(t, { bubbles: true })));
                    break;
                }
                await wait(200);
            }
            await wait(400);

            const saved = await clickSave();
            if (!saved) { prolongRunning = false; return false; }

            incProlongCount();
            flashSuccess(reasonLabel);
            showToast(`✅ Prolonged! (${reasonLabel})`);

            // Reload after save
            await wait(1500);
            const active = document.activeElement;
            const typing = active && (active.tagName === 'INPUT' || active.tagName === 'TEXTAREA' || active.isContentEditable);
            if (!typing) location.reload();

            prolongRunning = false;
            return true;
        } catch(e) {
            prolongRunning = false;
            return false;
        }
    }

    function updateProlongStatus(text, color = '#6c5ce7') {
        const el = document.getElementById('autoprolong-status');
        if (el) { el.innerText = text; el.style.background = color; }
    }

    // ── Auto prolong tick (checks every N sec, fires when button appears) ──
    const AUTO_CHECK_MS = 5000;

    async function autoTick() {
        if (!autoActive || prolongRunning) return;
        const btn = findProlongBtn();
        const modal = document.querySelector('[data-testid="select_input_prolongation_reason"]');
        if (btn || modal) {
            updateProlongStatus('🔄 Prolonging...', '#fdcb6e');
            const ok = await doProlongation();
            updateProlongStatus(ok ? '✅ Done!' : '⚠️ Error', ok ? '#00b894' : '#d63031');
            setTimeout(() => { if (autoActive) updateProlongStatus('👀 Waiting...'); }, 3000);
        } else {
            updateProlongStatus('👀 Waiting...');
        }
    }

    function startAutoProlong() {
        autoActive = true;
        localStorage.setItem(storageKey('auto_on'), 'true');
        if (autoCheckTimer) clearInterval(autoCheckTimer);
        autoCheckTimer = setInterval(autoTick, AUTO_CHECK_MS);
        updateToggleBtn();
        updateProlongStatus('👀 Waiting...');
        startTitleFlash('⏱');
    }

    function stopAutoProlong() {
        autoActive = false;
        localStorage.removeItem(storageKey('auto_on'));
        if (autoCheckTimer) { clearInterval(autoCheckTimer); autoCheckTimer = null; }
        updateToggleBtn();
        updateProlongStatus('⏸ Disabled', '#636e72');
        stopTitleFlash();
    }

    function updateToggleBtn() {
        const btn = document.getElementById('autoprolong-toggle');
        if (!btn) return;
        btn.innerText = autoActive ? '🟢 Auto ON' : '⚪ Auto OFF';
        btn.style.background = autoActive ? '#00b894' : '#636e72';
    }

    // ── Custom prolong (fires on interval regardless of button) ──
    function getCustomMs() {
        const h = parseInt(localStorage.getItem(storageKey('custom_h')) || '0');
        const m = parseInt(localStorage.getItem(storageKey('custom_m')) || '30');
        return ((h * 60) + m) * 60 * 1000;
    }

    function updateCustomCountdown() {
        const el = document.getElementById('custom-prolong-next');
        if (!el || !customNextFireAt) return;
        const diff = customNextFireAt - Date.now();
        if (diff <= 0) { el.innerText = 'Firing soon...'; return; }
        const h = Math.floor(diff / 3600000);
        const m = Math.floor((diff % 3600000) / 60000);
        const s = Math.floor((diff % 60000) / 1000);
        el.innerText = h > 0 ? `Next in ${h}h ${m}m` : `Next in ${m}m ${s}s`;
        el.style.color = '#a29bfe';
    }

    async function customFire() {
        const ms = getCustomMs();
        customNextFireAt = Date.now() + ms;
        if (!prolongRunning) {
            const customSt = document.getElementById('custom-prolong-status');
            if (customSt) { customSt.innerText = '🔄 Prolonging...'; customSt.style.color = '#fdcb6e'; }
            // Reload before
            location.reload();
            // After reload the startCustomProlong will resume via localStorage flag
        }
    }

    function startCustomProlong() {
        const ms = getCustomMs();
        if (ms < 60000) {
            const st = document.getElementById('custom-prolong-status');
            if (st) st.innerText = '⚠️ Min 1 min';
            return;
        }
        customActive = true;
        localStorage.setItem(storageKey('custom_on'), 'true');
        if (customTimer) clearInterval(customTimer);
        if (customCountdownTimer) clearInterval(customCountdownTimer);
        customNextFireAt = Date.now() + ms;
        customTimer = setInterval(customFire, ms);
        customCountdownTimer = setInterval(updateCustomCountdown, 1000);
        updateCustomCountdown();
        updateCustomToggleBtn();
        startTitleFlash('🟣');
    }

    function stopCustomProlong() {
        customActive = false;
        localStorage.removeItem(storageKey('custom_on'));
        if (customTimer) { clearInterval(customTimer); customTimer = null; }
        if (customCountdownTimer) { clearInterval(customCountdownTimer); customCountdownTimer = null; }
        customNextFireAt = null;
        updateCustomToggleBtn();
        const el = document.getElementById('custom-prolong-next');
        if (el) { el.innerText = 'Not scheduled'; el.style.color = '#636e72'; }
        if (!autoActive) stopTitleFlash();
    }

    function updateCustomToggleBtn() {
        const btn = document.getElementById('custom-prolong-toggle');
        if (!btn) return;
        btn.innerText = customActive ? '🟣 Custom ON' : '⚫ Custom OFF';
        btn.style.background = customActive ? '#a29bfe' : '#2d3436';
    }

    // ── Handover ──
    async function runHandover() {
        const btn = document.getElementById('handover-btn');
        if (btn) { btn.disabled = true; btn.innerText = '⏳...'; }
        try {
            document.querySelector('svg[data-icon="pen"]')?.closest('button')?.click();
            await wait(800);
            await setReactSelect('select_input_owner', 'CRM', 'select_option_crm_bot');
            await wait(300);
            await setReactSelect('select_input_pool', 'inc', getHandoverPoolTestId());
            await wait(300);
            await clickSave();
            const myId = getTicketId();
            if (myId) channel.postMessage({ type: 'ticket_handovered', id: myId });
        } finally {
            if (btn) { btn.disabled = false; btn.innerText = '🔁 Handover'; }
        }
    }

    // ── Toast ──
    function showToast(msg, color = '#00b894') {
        const t = document.createElement('div');
        t.innerText = msg;
        t.style.cssText = `position:fixed;bottom:30px;left:50%;transform:translateX(-50%);z-index:99999;padding:12px 20px;background:${color};color:#fff;border-radius:8px;font-size:14px;font-weight:bold;box-shadow:0 2px 8px rgba(0,0,0,0.3);transition:opacity 0.5s;`;
        document.body.appendChild(t);
        setTimeout(() => { t.style.opacity = '0'; }, 3000);
        setTimeout(() => { t.remove(); }, 3500);
    }

    // ── Detect priority ──
    function detectPriority() {
        setInterval(() => {
            const el = [...document.querySelectorAll('div,span')]
                .find(e => e.children.length === 0 && ['Urgent','High','Normal','Low'].includes(e.innerText?.trim()));
            if (!el) return;
            const p = el.innerText.trim();
            const ind = document.getElementById('priority-indicator');
            if (ind) {
                const colors = { Urgent:'#d63031', High:'#e17055', Normal:'#fdcb6e', Low:'#00b894' };
                const emojis = { Urgent:'🔴', High:'🟠', Normal:'🟡', Low:'🟢' };
                ind.innerText = `${emojis[p]} ${p}`;
                ind.style.color = colors[p];
            }
        }, 3000);
    }

    // ── Scheduled handover ──
    let schedTimer = null;
    function startSchedule(timeStr) {
        if (schedTimer) { clearInterval(schedTimer); schedTimer = null; }
        if (!timeStr) return;
        schedTimer = setInterval(() => {
            const now = new Date();
            const [h, m] = timeStr.split(':').map(Number);
            if (now.getHours() === h && now.getMinutes() === m) {
                clearInterval(schedTimer); schedTimer = null;
                localStorage.removeItem(storageKey('sched_on'));
                const tog = document.getElementById('handover-sched-toggle');
                if (tog) { tog.innerText = '⚪ Sched OFF'; tog.style.background = '#636e72'; }
                const st = document.getElementById('handover-sched-status');
                if (st) { st.innerText = `✅ Done at ${timeStr}`; st.style.color = '#00b894'; }
                runHandover();
            }
        }, 15000);
    }

    // ── Check if closed on load ──
    async function checkAndCloseIfClosed() {
        // First check if this tab was opened by the extension (auto open)
        let isAuto = false;
        try {
            await new Promise(resolve => {
                chrome.runtime.sendMessage({ type: 'is_auto_opened' }, (res) => {
                    if (!chrome.runtime.lastError) isAuto = res?.isAuto || false;
                    resolve();
                });
            });
        } catch(e) {}

        if (!isAuto) {
            console.log('[CRM Tools] Tab not auto-opened, skip close check');
            return;
        }

        // Wait for Status field to appear in DOM
        let status = '';
        for (let i = 0; i < 20; i++) {
            await new Promise(r => setTimeout(r, 500));
            const rows = [...document.querySelectorAll('[data-testid="row-name"]')];
            for (const row of rows) {
                const label = row.querySelector('[class*="RowName__title"]')?.innerText?.trim();
                if (label === 'Status') {
                    const val = row.parentElement?.querySelector('[data-testid="row-value"]')?.innerText?.trim();
                    if (val) { status = val; break; }
                }
            }
            if (status) break;
        }

        console.log('[CRM Tools] Status:', status, '| auto-opened:', isAuto);
        if (status && /^(closed|terminated)/i.test(status)) {
            console.log('[CRM Tools] Auto-closing tab — status:', status);
            try {
                chrome.runtime.sendMessage({ type: 'close_current_tab' });
            } catch(e) {}
        }
    }

    // ── Message handler for ticket page ──
    chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
        if (msg.type === 'get_ticket_data') {
            try {
                const fields = {};
                [...document.querySelectorAll('[data-testid="row-name"]')].forEach(row => {
                    const label = row.querySelector('[class*="RowName__title"]')?.innerText?.trim();
                    const val = row.parentElement?.querySelector('[data-testid="row-value"]')?.innerText?.trim();
                    if (label && val) fields[label] = val;
                });
                sendResponse({
                    id: getTicketId(),
                    guests: fields['Guests'] || '',
                    client: fields['Account\nE-mail'] || '',
                    hotel: fields['Hotel'] || '',
                    status: fields['Status'] || '',
                    priority: fields['Priority'] || '',
                    owner: fields['Owner'] || '',
                });
            } catch(e) {
                sendResponse({ id: getTicketId(), status: '', guests: '', hotel: '' });
            }
            return false;
        }
    });

    // ── Ticket page init ──
    function initTicketPage() {
        if (!location.href.match(/\/tickets\/\d+/)) return;

        const myId = getTicketId();

        // Ping-pong for open tab detection
        channel.addEventListener('message', (e) => {
            if (e.data.type === 'ping') channel.postMessage({ type: 'pong', id: myId });
            if (e.data.type === 'bulk_handover') runHandover();
        });

        // Check if closed and close tab
        checkAndCloseIfClosed();

        // Build sidebar
        buildSidebar();

        // Resume states
        if (localStorage.getItem(storageKey('auto_on')) === 'true') startAutoProlong();
        if (localStorage.getItem(storageKey('custom_on')) === 'true') startCustomProlong();
        const schedTime = localStorage.getItem(storageKey('sched_time'));
        if (localStorage.getItem(storageKey('sched_on')) === 'true' && schedTime) startSchedule(schedTime);

        detectPriority();
    }

    // ── Build sidebar UI ──
    function buildSidebar() {
        if (document.getElementById('crm-sidebar')) return;

        // Tab button
        const tab = document.createElement('div');
        tab.id = 'crm-sidebar-tab';
        tab.style.cssText = `position:fixed;top:50%;right:0;transform:translateY(-50%);z-index:9999;background:#6c5ce7;color:#fff;padding:12px 5px;border-radius:8px 0 0 8px;cursor:pointer;font-size:10px;font-weight:900;writing-mode:vertical-rl;letter-spacing:0.1em;box-shadow:-2px 0 10px rgba(108,92,231,0.4);user-select:none;transition:right 0.25s;`;
        tab.innerText = 'CRM TOOLS';
        document.body.appendChild(tab);

        // Sidebar
        const sidebar = document.createElement('div');
        sidebar.id = 'crm-sidebar';
        sidebar.style.cssText = `position:fixed;top:0;right:0;width:210px;height:100vh;z-index:9998;background:#131920;border-left:1px solid #1e2330;box-shadow:-4px 0 20px rgba(0,0,0,0.4);display:flex;flex-direction:column;overflow-y:auto;transform:translateX(100%);transition:transform 0.25s;padding-bottom:20px;`;
        document.body.appendChild(sidebar);

        let open = false;
        function toggle() {
            open = !open;
            sidebar.style.transform = open ? 'translateX(0)' : 'translateX(100%)';
            tab.style.right = open ? '210px' : '0';
        }
        tab.onclick = toggle;

        // Header
        const hdr = el('div', `padding:14px;border-bottom:1px solid #1e2330;display:flex;justify-content:space-between;align-items:center;`);
        const htitle = el('div', `font-size:11px;font-weight:900;color:#6c5ce7;letter-spacing:0.15em;text-transform:uppercase;`); htitle.innerText = 'CRM Tools';
        const hclose = el('button', `background:none;border:none;color:#636e72;cursor:pointer;font-size:14px;`); hclose.innerText = '✕'; hclose.onclick = toggle;
        hdr.appendChild(htitle); hdr.appendChild(hclose);
        sidebar.appendChild(hdr);

        const body = el('div', `padding:10px;display:flex;flex-direction:column;gap:8px;`);
        sidebar.appendChild(body);

        function el(tag, css, text) {
            const e = document.createElement(tag);
            if (css) e.style.cssText = css;
            if (text) e.innerText = text;
            return e;
        }

        function label(txt) {
            const l = el('div', `font-size:9px;font-weight:700;letter-spacing:0.15em;text-transform:uppercase;color:#636e72;margin-top:4px;`);
            l.innerText = txt; return l;
        }

        function btn(id, text, bg, onclick) {
            const b = el('button', `padding:8px;background:${bg};color:#fff;border:none;border-radius:8px;font-size:12px;font-weight:bold;cursor:pointer;width:100%;text-align:left;`);
            b.id = id; b.innerText = text; b.onclick = onclick; return b;
        }

        // ── Handover ──
        body.appendChild(label('Handover'));
        body.appendChild(btn('handover-btn', '🔁 Handover', '#6c5ce7', runHandover));

        // ── Prolong reason ──
        body.appendChild(label('Prolong Reason'));
        const grid = el('div', `display:grid;grid-template-columns:1fr 1fr;gap:4px;`);
        body.appendChild(grid);

        function setReason(testid) {
            localStorage.setItem(storageKey('prolong_reason'), testid);
            grid.querySelectorAll('button').forEach(b => {
                const active = b.dataset.testid === testid;
                b.style.opacity = active ? '1' : '0.3';
                b.style.transform = active ? 'scale(1.04)' : 'scale(1)';
            });
        }

        PROLONG_REASONS.forEach(r => {
            const b = el('button', `padding:6px 4px;background:${r.color};color:#fff;border:none;border-radius:6px;font-size:10px;font-weight:700;cursor:pointer;transition:all 0.15s;opacity:0.3;`);
            b.dataset.testid = r.testid; b.innerText = r.label;
            b.onclick = () => setReason(r.testid);
            grid.appendChild(b);
        });
        setReason(getSavedReason());

        // ── Auto prolong ──
        body.appendChild(label('Auto Prolongation'));

        const countdown = el('div', `font-size:10px;color:#636e72;`); countdown.id = 'prolong-countdown'; countdown.innerText = '👀 Waits for button'; body.appendChild(countdown);
        const counter = el('div', `font-size:10px;color:#b2bec3;`); counter.id = 'prolong-counter'; counter.innerText = `🔢 Prolonged: ${getProlongCount()}x`; body.appendChild(counter);

        const autoToggle = btn('autoprolong-toggle', autoActive ? '🟢 Auto ON' : '⚪ Auto OFF', autoActive ? '#00b894' : '#636e72', () => autoActive ? stopAutoProlong() : startAutoProlong());
        body.appendChild(autoToggle);

        const statusEl = el('div', `padding:5px 8px;background:${autoActive ? '#6c5ce7' : '#636e72'};color:#fff;border-radius:6px;font-size:11px;font-weight:bold;text-align:center;`);
        statusEl.id = 'autoprolong-status'; statusEl.innerText = autoActive ? '👀 Waiting...' : '⏸ Disabled';
        body.appendChild(statusEl);

        // ── Custom prolong ──
        body.appendChild(label('Custom Prolongation'));

        const cRow = el('div', `display:grid;grid-template-columns:1fr auto 1fr;gap:4px;align-items:center;`);
        const hInp = el('input', `padding:5px;background:#1e272e;color:#fff;border:1px solid #2d3436;border-radius:6px;font-size:12px;text-align:center;`);
        hInp.type = 'number'; hInp.min = '0'; hInp.max = '23'; hInp.id = 'custom-prolong-hours';
        hInp.value = localStorage.getItem(storageKey('custom_h')) || '0';
        hInp.placeholder = 'h';
        const sep = el('div', `color:#636e72;text-align:center;font-weight:700;`); sep.innerText = ':';
        const mInp = el('input', `padding:5px;background:#1e272e;color:#fff;border:1px solid #2d3436;border-radius:6px;font-size:12px;text-align:center;`);
        mInp.type = 'number'; mInp.min = '0'; mInp.max = '59'; mInp.id = 'custom-prolong-mins';
        mInp.value = localStorage.getItem(storageKey('custom_m')) || '30';
        mInp.placeholder = 'm';

        [hInp, mInp].forEach(inp => inp.onchange = () => {
            localStorage.setItem(storageKey('custom_h'), hInp.value);
            localStorage.setItem(storageKey('custom_m'), mInp.value);
            if (customActive) { stopCustomProlong(); startCustomProlong(); }
        });

        cRow.appendChild(hInp); cRow.appendChild(sep); cRow.appendChild(mInp);
        body.appendChild(cRow);

        const cNext = el('div', `font-size:10px;color:#636e72;text-align:center;`); cNext.id = 'custom-prolong-next'; cNext.innerText = 'Not scheduled'; body.appendChild(cNext);

        const cToggle = btn('custom-prolong-toggle', customActive ? '🟣 Custom ON' : '⚫ Custom OFF', customActive ? '#a29bfe' : '#2d3436', () => customActive ? stopCustomProlong() : startCustomProlong());
        body.appendChild(cToggle);

        const cStatus = el('div', `font-size:10px;color:#636e72;text-align:center;padding:2px 0;`); cStatus.id = 'custom-prolong-status'; cStatus.innerText = 'Fires on interval'; body.appendChild(cStatus);

        // ── Priority ──
        body.appendChild(label('Priority'));
        const prioEl = el('div', `font-size:10px;color:#b2bec3;padding:3px 0;`); prioEl.id = 'priority-indicator'; prioEl.innerText = 'Detecting...'; body.appendChild(prioEl);

        // ── Counter ──
        const ctrEl = el('div', `font-size:10px;color:#b2bec3;`); ctrEl.id = 'prolong-counter2'; ctrEl.innerText = `Prolonged: ${getProlongCount()}x`;

        // ── Notes ──
        body.appendChild(label('Quick Notes'));
        const notes = el('textarea', `width:100%;height:80px;background:#1e272e;color:#dfe6e9;border:1px solid #2d3436;border-radius:6px;padding:6px 8px;font-size:11px;resize:none;font-family:monospace;line-height:1.5;`);
        notes.placeholder = 'Notes for this ticket...';
        notes.value = localStorage.getItem(storageKey('notes')) || '';
        notes.oninput = () => localStorage.setItem(storageKey('notes'), notes.value);
        body.appendChild(notes);

        const clrBtn = el('button', `padding:5px 8px;background:#2d3436;color:#b2bec3;border:none;border-radius:6px;font-size:10px;cursor:pointer;width:100%;`);
        clrBtn.innerText = '🗑 Clear notes';
        clrBtn.onclick = () => { notes.value = ''; localStorage.removeItem(storageKey('notes')); };
        body.appendChild(clrBtn);

        // ── Scheduled handover ──
        body.appendChild(label('Scheduled Handover'));
        const sRow = el('div', `display:flex;gap:6px;align-items:center;`);
        const sInp = el('input', `flex:1;padding:5px;background:#1e272e;color:#fff;border:1px solid #2d3436;border-radius:6px;font-size:11px;`);
        sInp.type = 'time'; sInp.id = 'handover-time-input';
        sInp.value = localStorage.getItem(storageKey('sched_time')) || '';
        sInp.onchange = () => {
            localStorage.setItem(storageKey('sched_time'), sInp.value);
            if (localStorage.getItem(storageKey('sched_on')) === 'true') startSchedule(sInp.value);
            updateSchedStatus();
        };
        sRow.appendChild(sInp); body.appendChild(sRow);

        const sTog = el('button', `padding:6px 8px;background:${localStorage.getItem(storageKey('sched_on')) === 'true' ? '#00b894' : '#636e72'};color:#fff;border:none;border-radius:7px;font-size:11px;font-weight:700;cursor:pointer;width:100%;`);
        sTog.id = 'handover-sched-toggle';
        sTog.innerText = localStorage.getItem(storageKey('sched_on')) === 'true' ? '🟢 Sched ON' : '⚪ Sched OFF';
        sTog.onclick = () => {
            const on = localStorage.getItem(storageKey('sched_on')) === 'true';
            if (on) {
                localStorage.removeItem(storageKey('sched_on'));
                if (schedTimer) { clearInterval(schedTimer); schedTimer = null; }
                sTog.innerText = '⚪ Sched OFF'; sTog.style.background = '#636e72';
            } else {
                const t = localStorage.getItem(storageKey('sched_time'));
                if (!t) { updateSchedStatus('⚠️ Set time first'); return; }
                localStorage.setItem(storageKey('sched_on'), 'true');
                startSchedule(t);
                sTog.innerText = '🟢 Sched ON'; sTog.style.background = '#00b894';
            }
            updateSchedStatus();
        };
        body.appendChild(sTog);

        const sSt = el('div', `font-size:10px;color:#636e72;padding:2px 0;`); sSt.id = 'handover-sched-status'; body.appendChild(sSt);

        function updateSchedStatus(msg) {
            const e = document.getElementById('handover-sched-status'); if (!e) return;
            if (msg) { e.innerText = msg; return; }
            const t = localStorage.getItem(storageKey('sched_time'));
            const on = localStorage.getItem(storageKey('sched_on')) === 'true';
            e.innerText = !t ? 'No time set' : on ? `⏰ Will run at ${t}` : `Set: ${t} (off)`;
            e.style.color = on ? '#fdcb6e' : '#636e72';
        }
        updateSchedStatus();

        // Resume countdown if custom was active
        if (customActive) updateCustomCountdown();
    }


    // ─────────────────────────────────────────
    // ══════════════════════════════════════════
    // LIST PAGE
    // ══════════════════════════════════════════
    // ─────────────────────────────────────────

    let autoOpenTimer = null;
    let autoReloadTimer = null;
    let isRunning = false;
    let reloadCycleRunning = false;
    const recentlyHandovered = new Set();

    // Listen for handovered events
    channel.addEventListener('message', (e) => {
        if (e.data.type === 'ticket_handovered' && e.data.id) {
            recentlyHandovered.add(String(e.data.id));
            setTimeout(() => recentlyHandovered.delete(String(e.data.id)), 10 * 60 * 1000);
        }
    });

    function getTicketLinks() {
        return [...document.querySelectorAll('a')]
            .filter(a => /\/tickets\/\d+\/$/.test(a.href))
            .map(a => ({ href: a.href, id: String(a.href.match(/\/tickets\/(\d+)\//)?.[1]) }))
            .filter(t => t.id && t.id !== 'undefined');
    }

    function getPageItems() {
        return [...document.querySelectorAll('[class*="Paginator__item"]')];
    }

    function getTotalPages() {
        const nums = getPageItems().map(e => parseInt(e.innerText?.trim())).filter(n => !isNaN(n));
        return nums.length ? Math.max(...nums) : 1;
    }

    async function goToPage(n) {
        const t = getPageItems().find(e => e.innerText?.trim() === String(n));
        if (t) { t.click(); await wait(1200); return true; }
        return false;
    }

    async function getOpenTabIds() {
        return new Promise(resolve => {
            const found = new Set([...recentlyHandovered]);
            const ch = new BroadcastChannel('crm_tickets');
            ch.onmessage = (e) => { if (e.data.type === 'pong') found.add(String(e.data.id)); };
            ch.postMessage({ type: 'ping' });
            setTimeout(() => { ch.close(); resolve(found); }, 1800);
        });
    }

    async function getLiveStatuses() {
        return new Promise(resolve => {
            const map = new Map();
            try {
                chrome.runtime.sendMessage({ type: 'get_all_ticket_statuses' }, (res) => {
                    if (chrome.runtime.lastError || !res?.statuses) { resolve(map); return; }
                    res.statuses.forEach(({ id, status }) => {
                        if (id && status) map.set(String(id), status.toLowerCase());
                    });
                    resolve(map);
                });
                setTimeout(() => resolve(map), 2500);
            } catch(e) { resolve(map); }
        });
    }

    function getDomStatuses() {
        const map = new Map();
        [...document.querySelectorAll('tr')].filter(r => r.querySelector('a[href*="/tickets/"]')).forEach(row => {
            const id = row.querySelector('a[href*="/tickets/"]')?.href?.match(/\/tickets\/(\d+)\//)?.[1];
            if (!id) return;
            const statusCell = [...row.querySelectorAll('td')].find(c =>
                c.children.length <= 1 && /^(open|closed|resolved|pending|cancelled)/i.test(c.innerText?.trim())
            );
            if (statusCell) map.set(String(id), statusCell.innerText.trim().toLowerCase());
        });
        return map;
    }

    function isClosed(id, domStatuses, liveStatuses) {
        const live = liveStatuses.get(String(id));
        const dom = domStatuses.get(String(id));
        return /^(closed|resolved|cancelled)/i.test(live || dom || '');
    }

    async function collectAllTickets() {
        const all = new Map();
        const total = getTotalPages();
        for (let p = 1; p <= total; p++) {
            if (p > 1) await goToPage(p);
            getTicketLinks().forEach(t => all.set(t.id, t.href));
            updateListStatus(`Scanning ${p}/${total} — ${all.size} tickets`);
        }
        if (total > 1) await goToPage(1);
        return all;
    }

    function openInBackground(urls) {
        return new Promise(resolve => {
            if (!urls.length) { resolve(0); return; }
            try {
                chrome.runtime.sendMessage({ type: 'open_tabs_background', urls }, (res) => {
                    if (chrome.runtime.lastError) { urls.forEach(u => window.open(u, '_blank', 'noopener')); resolve(urls.length); return; }
                    resolve(res?.opened || 0);
                });
            } catch(e) { urls.forEach(u => window.open(u, '_blank', 'noopener')); resolve(urls.length); }
        });
    }

    async function openNewTickets() {
        if (isRunning) return;
        isRunning = true;
        setListBtnsDisabled(true);
        try {
            updateListStatus('Scanning...');
            const all = await collectAllTickets();
            updateListStatus('Checking open tabs...');
            const [openIds, liveStatuses] = await Promise.all([getOpenTabIds(), getLiveStatuses()]);
            const domStatuses = getDomStatuses();

            const toOpen = [...all.entries()]
                .filter(([id]) => !openIds.has(id))
                .filter(([id]) => !isClosed(id, domStatuses, liveStatuses))
                .map(([, href]) => href);

            const skipped = [...all.keys()].filter(id => isClosed(id, domStatuses, liveStatuses)).length;
            updateListStatus(`Opening ${toOpen.length}...`);
            const opened = await openInBackground(toOpen);
            updateListStatus(`✅ ${opened} opened · ${skipped} closed skipped`);
        } finally {
            setListBtnsDisabled(false);
            isRunning = false;
        }
    }

    async function openAllTickets() {
        if (isRunning) return;
        isRunning = true;
        setListBtnsDisabled(true);
        try {
            const all = await collectAllTickets();
            const liveStatuses = await getLiveStatuses();
            const domStatuses = getDomStatuses();
            const urls = [...all.entries()]
                .filter(([id]) => !isClosed(id, domStatuses, liveStatuses))
                .map(([, href]) => href);
            const opened = await openInBackground(urls);
            updateListStatus(`✅ ${opened} opened`);
        } finally {
            setListBtnsDisabled(false);
            isRunning = false;
        }
    }

    function closeDuplicates() {
        updateListStatus('Closing duplicates...');
        try {
            chrome.runtime.sendMessage({ type: 'close_duplicate_tabs' }, (res) => {
                if (chrome.runtime.lastError) { updateListStatus('⚠️ Error'); return; }
                updateListStatus(`✅ Closed ${res?.closed || 0} duplicates`);
                setTimeout(() => updateListStatus('Ready'), 3000);
            });
        } catch(e) { updateListStatus('⚠️ Error'); }
    }

    function bulkHandover() {
        channel.postMessage({ type: 'bulk_handover' });
        updateListStatus('✅ Handover sent to all tabs');
        setTimeout(() => updateListStatus('Ready'), 3000);
    }

    function clickUpdateData() {
        return !!document.querySelector('[data-testid="filter_apply_filter"]')?.click();
    }

    async function doReloadCycle() {
        if (reloadCycleRunning) return;
        reloadCycleRunning = true;
        try {
            updateListStatus('🔄 Updating data...');
            clickUpdateData();
            await wait(3000);
            await openNewTickets();
        } finally {
            reloadCycleRunning = false;
        }
    }

    function startAutoOpen() {
        const min = parseInt(localStorage.getItem('crm_auto_open_min') || '5');
        localStorage.setItem('crm_auto_open', 'true');
        if (autoOpenTimer) { clearInterval(autoOpenTimer); autoOpenTimer = null; }
        autoOpenTimer = setInterval(() => { if (!isRunning) openNewTickets(); }, min * 60 * 1000);
        updateAutoOpenBtn(true);
        updateListStatus(`🔄 Auto every ${min} min`);
    }

    function stopAutoOpen() {
        localStorage.removeItem('crm_auto_open');
        if (autoOpenTimer) { clearInterval(autoOpenTimer); autoOpenTimer = null; }
        updateAutoOpenBtn(false);
        updateListStatus('Auto stopped');
    }

    function startAutoReload() {
        const min = parseInt(localStorage.getItem('crm_auto_reload_min') || '3');
        localStorage.setItem('crm_auto_reload_on', 'true');
        if (autoReloadTimer) { clearInterval(autoReloadTimer); autoReloadTimer = null; }
        autoReloadTimer = setInterval(doReloadCycle, min * 60 * 1000);
        updateReloadBtn(true);
        updateListStatus(`🔄 Reload every ${min} min`);
    }

    function stopAutoReload() {
        localStorage.removeItem('crm_auto_reload_on');
        if (autoReloadTimer) { clearInterval(autoReloadTimer); autoReloadTimer = null; }
        updateReloadBtn(false);
        updateListStatus('Reload stopped');
    }

    function setListBtnsDisabled(d) {
        ['open-new-btn','open-all-btn'].forEach(id => { const b = document.getElementById(id); if (b) b.disabled = d; });
    }

    function updateListStatus(t) {
        const e = document.getElementById('open-tickets-status'); if (e) e.innerText = t;
    }

    function updateAutoOpenBtn(on) {
        const b = document.getElementById('auto-open-btn'); if (!b) return;
        b.innerText = on ? '🟢 Auto ON' : '⚪ Auto OFF';
        b.style.background = on ? '#00b894' : '#636e72';
    }

    function updateReloadBtn(on) {
        const b = document.getElementById('auto-reload-btn'); if (!b) return;
        b.innerText = on ? '🔄 Reload ON' : '🔄 Reload OFF';
        b.style.background = on ? '#0984e3' : '#636e72';
    }

    function searchOpenTabs(query) {
        const results = document.getElementById('tab-search-results');
        if (!results) return;
        if (!query.trim()) { results.style.display = 'none'; results.innerHTML = ''; return; }
        results.style.display = 'flex';
        results.innerHTML = '<div style="color:#636e72;font-size:10px;padding:4px;">Searching...</div>';
        try {
            chrome.runtime.sendMessage({ type: 'search_tabs', query }, (res) => {
                if (chrome.runtime.lastError) { results.innerHTML = '<div style="color:#d63031;font-size:10px;padding:4px;">Error</div>'; return; }
                results.innerHTML = '';
                if (!res?.tabs?.length) { results.innerHTML = '<div style="color:#636e72;font-size:10px;padding:4px;">No results</div>'; return; }
                res.tabs.forEach(tab => {
                    const item = document.createElement('div');
                    item.style.cssText = `padding:6px 8px;background:#1e272e;border-radius:5px;font-size:11px;color:#dfe6e9;cursor:pointer;border:1px solid #2d3436;margin-bottom:2px;transition:background 0.1s;`;
                    const id = el2('div','font-weight:700;color:#a29bfe;font-size:11px;'); id.innerText = `#${tab.ticketId}`;
                    const g = el2('div','color:#b2bec3;font-size:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;'); g.innerText = tab.guests?.replace(/\n/g,', ').slice(0,50) || tab.hotel || '';
                    const s = el2('div','color:#636e72;font-size:9px;'); s.innerText = [tab.status, tab.hotel?.split('\n')[0]].filter(Boolean).join(' · ').slice(0,40);
                    item.appendChild(id); if(g.innerText) item.appendChild(g); if(s.innerText) item.appendChild(s);
                    item.onmouseenter = () => item.style.background = '#2d3436';
                    item.onmouseleave = () => item.style.background = '#1e272e';
                    item.onclick = () => { try { chrome.runtime.sendMessage({ type: 'focus_tab', tabId: tab.id }); } catch(e){} };
                    results.appendChild(item);
                });
            });
        } catch(e) { results.innerHTML = '<div style="color:#d63031;font-size:10px;padding:4px;">Extension error</div>'; }
    }

    function el2(tag, css) { const e = document.createElement(tag); e.style.cssText = css; return e; }

    function initListPage() {
        if (listUIInitialized) return;
        if (!location.href.includes('/tickets') || location.href.match(/\/tickets\/\d+/)) return;
        listUIInitialized = true;

        const wrap = document.createElement('div');
        wrap.id = 'crm-open-tickets-ui';
        wrap.style.cssText = `position:fixed;bottom:30px;right:20px;z-index:9999;display:flex;flex-direction:column;align-items:flex-end;gap:6px;`;

        const toggleBtn = document.createElement('button');
        toggleBtn.id = 'panel-toggle-btn';
        toggleBtn.innerText = '🔼 Hide';
        toggleBtn.style.cssText = `padding:4px 10px;background:#2d3436;color:#b2bec3;border:none;border-radius:6px;font-size:11px;cursor:pointer;`;
        toggleBtn.onclick = () => {
            const inner = document.getElementById('open-tickets-inner');
            const hidden = inner.style.display === 'none';
            inner.style.display = hidden ? 'flex' : 'none';
            toggleBtn.innerText = hidden ? '🔼 Hide' : '🔽 Tools';
        };
        wrap.appendChild(toggleBtn);

        const inner = document.createElement('div');
        inner.id = 'open-tickets-inner';
        inner.style.cssText = `display:flex;flex-direction:column;align-items:stretch;gap:6px;background:#1e272e;padding:10px;border-radius:10px;box-shadow:0 4px 12px rgba(0,0,0,0.4);min-width:200px;`;

        const status = document.createElement('div');
        status.id = 'open-tickets-status'; status.innerText = 'Ready';
        status.style.cssText = `color:#b2bec3;font-size:11px;text-align:center;`;
        inner.appendChild(status);

        // Shift selector
        const shiftRow = document.createElement('div');
        shiftRow.style.cssText = 'display:grid;grid-template-columns:1fr 1fr;gap:4px;';
        function mkShiftBtn(label, val, color) {
            const b = document.createElement('button');
            b.innerText = label; b.style.cssText = `padding:6px;background:${color};color:#fff;border:none;border-radius:6px;font-size:11px;font-weight:700;cursor:pointer;transition:all 0.15s;`;
            b.onclick = () => { localStorage.setItem('crm_handover_shift', val); updateShift(); };
            b.dataset.shift = val;
            return b;
        }
        const dayBtn = mkShiftBtn('☀️ Day', 'day', '#0984e3');
        const nightBtn = mkShiftBtn('🌙 Night', 'night', '#6c5ce7');
        shiftRow.appendChild(dayBtn); shiftRow.appendChild(nightBtn);
        inner.appendChild(shiftRow);

        function updateShift() {
            const s = localStorage.getItem('crm_handover_shift') || 'day';
            dayBtn.style.opacity = s === 'day' ? '1' : '0.35';
            nightBtn.style.opacity = s === 'night' ? '1' : '0.35';
        }
        updateShift();

        function mkBtn(id, text, bg, cb) {
            const b = document.createElement('button');
            b.id = id; b.innerText = text;
            b.style.cssText = `padding:8px 14px;background:${bg};color:#fff;border:none;border-radius:8px;font-size:12px;font-weight:bold;cursor:pointer;`;
            b.onclick = cb; return b;
        }

        inner.appendChild(mkBtn('open-new-btn','📂 Open New Tickets','#6c5ce7', openNewTickets));
        inner.appendChild(mkBtn('open-all-btn','📂 Open All Tickets','#0984e3', openAllTickets));
        inner.appendChild(mkBtn('close-dupes-btn','🗂 Close Duplicates','#d63031', closeDuplicates));
        inner.appendChild(mkBtn('bulk-handover-btn','⚡ Bulk Handover','#e17055', bulkHandover));

        const sep1 = document.createElement('div'); sep1.style.cssText = 'height:1px;background:#2d3436;'; inner.appendChild(sep1);

        // Search
        const sInp = document.createElement('input');
        sInp.placeholder = '🔍 Search open tabs...';
        sInp.style.cssText = `padding:5px 8px;background:#2d3436;color:#fff;border:1px solid #636e72;border-radius:6px;font-size:11px;`;
        sInp.oninput = () => searchOpenTabs(sInp.value);
        inner.appendChild(sInp);

        const sResults = document.createElement('div');
        sResults.id = 'tab-search-results';
        sResults.style.cssText = `display:none;flex-direction:column;gap:2px;height:130px;overflow-y:auto;border:1px solid #2d3436;border-radius:6px;padding:3px;background:#0d0f14;`;
        inner.appendChild(sResults);

        const sep2 = document.createElement('div'); sep2.style.cssText = 'height:1px;background:#2d3436;'; inner.appendChild(sep2);

        // Auto open timer
        function mkTimerRow(labelTxt, storeKey, inputId) {
            const row = document.createElement('div'); row.style.cssText = 'display:flex;align-items:center;gap:6px;';
            const lbl = document.createElement('span'); lbl.innerText = labelTxt; lbl.style.cssText = 'color:#b2bec3;font-size:11px;white-space:nowrap;';
            const inp = document.createElement('input'); inp.type = 'number'; inp.min = '1'; inp.max = '60';
            inp.value = localStorage.getItem(storeKey) || '5'; inp.id = inputId;
            inp.style.cssText = `width:45px;padding:4px 6px;background:#2d3436;color:#fff;border:1px solid #636e72;border-radius:4px;font-size:12px;`;
            inp.onchange = () => {
                localStorage.setItem(storeKey, inp.value);
                if (storeKey === 'crm_auto_open_min' && localStorage.getItem('crm_auto_open') === 'true') startAutoOpen();
                if (storeKey === 'crm_auto_reload_min' && localStorage.getItem('crm_auto_reload_on') === 'true') startAutoReload();
            };
            row.appendChild(lbl); row.appendChild(inp); return row;
        }

        inner.appendChild(mkTimerRow('⏱ open (min):', 'crm_auto_open_min', 'auto-open-input'));
        inner.appendChild(mkBtn('auto-open-btn','⚪ Auto OFF','#636e72', () => localStorage.getItem('crm_auto_open') === 'true' ? stopAutoOpen() : startAutoOpen()));

        inner.appendChild(mkTimerRow('🔄 reload (min):', 'crm_auto_reload_min', 'auto-reload-input'));
        inner.appendChild(mkBtn('auto-reload-btn','🔄 Reload OFF','#636e72', () => localStorage.getItem('crm_auto_reload_on') === 'true' ? stopAutoReload() : startAutoReload()));

        wrap.appendChild(inner);
        document.body.appendChild(wrap);

        // Resume timers
        if (localStorage.getItem('crm_auto_open') === 'true') startAutoOpen();
        if (localStorage.getItem('crm_auto_reload_on') === 'true') startAutoReload();

        // Watch for panel disappearing after Update data
        let reinitPending = false;
        new MutationObserver(() => {
            if (!document.getElementById('crm-open-tickets-ui') && !reinitPending &&
                location.href.includes('/tickets') && !location.href.match(/\/tickets\/\d+/)) {
                reinitPending = true;
                setTimeout(() => {
                    reinitPending = false;
                    if (!document.getElementById('crm-open-tickets-ui')) {
                        if (autoOpenTimer) { clearInterval(autoOpenTimer); autoOpenTimer = null; }
                        if (autoReloadTimer) { clearInterval(autoReloadTimer); autoReloadTimer = null; }
                        listUIInitialized = false;
                        initListPage();
                    }
                }, 800);
            }
        }).observe(document.body, { childList: true, subtree: false });
    }

})();
