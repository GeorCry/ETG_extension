(function () {
    const wait = (ms) => new Promise(r => setTimeout(r, ms));
    const channel = new BroadcastChannel('crm_tickets');

    // ─────────────────────────────────────────
    // NAVIGATION WATCHER
    // ─────────────────────────────────────────
    let lastUrl = location.href;

    function onUrlChange(newUrl) {
        lastUrl = newUrl;
        document.getElementById('crm-open-tickets-ui')?.remove();
        document.getElementById('crm-tools-ui')?.remove();
        document.getElementById('crm-sidebar')?.remove();
        if (newUrl.match(/\/tickets\/\d+/)) setTimeout(initTicketUI, 1500);
        else if (newUrl.includes('/tickets')) setTimeout(initListUI, 1500);
    }

    const _pushState = history.pushState.bind(history);
    history.pushState = function (...args) {
        _pushState(...args);
        setTimeout(() => { if (location.href !== lastUrl) onUrlChange(location.href); }, 100);
    };
    window.addEventListener('popstate', () => {
        setTimeout(() => { if (location.href !== lastUrl) onUrlChange(location.href); }, 100);
    });
    setInterval(() => { if (location.href !== lastUrl) onUrlChange(location.href); }, 500);

    // ─────────────────────────────────────────
    // TICKET PAGE — ping response
    // ─────────────────────────────────────────
    if (location.href.match(/\/tickets\/\d+/)) {
        const myId = location.href.match(/\/tickets\/(\d+)/)?.[1];
        if (myId) {
            channel.onmessage = (e) => {
                if (e.data.type === 'ping') channel.postMessage({ type: 'pong', id: myId });
                if (e.data.type === 'bulk_handover') runHandover();
            };
        }
        setTimeout(initTicketUI, 2000);
    } else if (location.href.includes('/tickets')) {
        setTimeout(initListUI, 2000);
    }

    // ─────────────────────────────────────────
    // LIST PAGE — Open Tickets
    // ─────────────────────────────────────────
    const STORAGE_AUTO_KEY = 'crm_auto_open';
    const STORAGE_TIMER_KEY = 'crm_auto_timer_min';
    const STORAGE_RELOAD_KEY = 'crm_auto_reload_min';
    let autoOpenTimer = null;
    let autoReloadTimer = null;
    let isRunning = false;

    function getTicketLinks() {
        return [...document.querySelectorAll('a')]
            .filter(a => /\/tickets\/\d+\/$/.test(a.href))
            .map(a => ({ href: a.href, id: a.href.match(/\/tickets\/(\d+)\//)?.[1] }))
            .filter(t => t.id);
    }

    function getAllPageItems() {
        return [...document.querySelectorAll('[class*="Paginator__item"]')];
    }

    function getTotalPages() {
        const items = getAllPageItems();
        if (items.length === 0) return 1;
        const nums = items.map(el => parseInt(el.innerText?.trim())).filter(n => !isNaN(n));
        return Math.max(...nums, 1);
    }

    async function goToPage(pageNum) {
        const items = getAllPageItems();
        const target = items.find(el => el.innerText?.trim() === String(pageNum));
        if (target) { target.click(); await wait(1200); return true; }
        return false;
    }

    async function getOpenTabIds(timeoutMs = 800) {
        return new Promise(resolve => {
            const found = new Set();
            channel.onmessage = (e) => { if (e.data.type === 'pong') found.add(e.data.id); };
            channel.postMessage({ type: 'ping' });
            setTimeout(() => resolve(found), timeoutMs);
        });
    }

    async function collectAllTickets() {
        const allLinks = new Map();
        const totalPages = getTotalPages();
        for (let page = 1; page <= totalPages; page++) {
            if (page > 1) await goToPage(page);
            getTicketLinks().forEach(t => allLinks.set(t.id, t.href));
            updateListStatus(`Scanning page ${page}/${totalPages} — ${allLinks.size} tickets`);
        }
        if (totalPages > 1) await goToPage(1);
        return allLinks;
    }

    function openTabsInBackground(urls) {
        return new Promise(resolve => {
            if (!urls || urls.length === 0) { resolve(0); return; }
            try {
                chrome.runtime.sendMessage({ type: 'open_tabs_background', urls }, (res) => {
                    if (chrome.runtime.lastError) {
                        urls.forEach(url => window.open(url, '_blank', 'noopener'));
                        resolve(urls.length);
                        return;
                    }
                    resolve(res?.opened || 0);
                });
            } catch (e) {
                urls.forEach(url => window.open(url, '_blank', 'noopener'));
                resolve(urls.length);
            }
        });
    }

    async function openNewTickets() {
        if (isRunning) return;
        isRunning = true;
        setListBtnsDisabled(true);
        updateListStatus('Scanning pages...');
        const allLinks = await collectAllTickets();
        updateListStatus('Checking open tabs...');
        const openIds = await getOpenTabIds();
        const toOpen = [...allLinks.entries()].filter(([id]) => !openIds.has(id)).map(([, href]) => href);
        updateListStatus(`Opening ${toOpen.length} new tickets...`);
        const opened = await openTabsInBackground(toOpen);
        updateListStatus(`✅ Opened ${opened} new / ${allLinks.size} total`);
        setListBtnsDisabled(false);
        isRunning = false;
    }

    async function openAllTickets() {
        if (isRunning) return;
        isRunning = true;
        setListBtnsDisabled(true);
        updateListStatus('Scanning pages...');
        const allLinks = await collectAllTickets();
        const urls = [...allLinks.values()];
        updateListStatus(`Opening all ${urls.length} tickets...`);
        const opened = await openTabsInBackground(urls);
        updateListStatus(`✅ Opened all ${opened} tickets`);
        setListBtnsDisabled(false);
        isRunning = false;
    }

    function closeDuplicateTabs() {
        updateListStatus('Checking duplicates...');
        try {
            chrome.runtime.sendMessage({ type: 'close_duplicate_tabs' }, (res) => {
                if (chrome.runtime.lastError) { updateListStatus('⚠️ Error'); return; }
                const closed = res?.closed || 0;
                updateListStatus(`✅ Closed ${closed} duplicate${closed !== 1 ? 's' : ''}`);
                setTimeout(() => updateListStatus('Ready'), 3000);
            });
        } catch(e) { updateListStatus('⚠️ Error'); }
    }

    async function bulkHandover() {
        if (isRunning) return;
        isRunning = true;
        updateListStatus('Broadcasting Handover...');
        channel.postMessage({ type: 'bulk_handover' });
        updateListStatus('✅ Handover sent to all open tickets');
        setTimeout(() => updateListStatus('Ready'), 4000);
        isRunning = false;
    }

    function clickUpdateData() {
        const btn = document.querySelector('[data-testid="filter_apply_filter"]');
        if (btn) { btn.click(); return true; }
        return false;
    }

    function startAutoOpen() {
        const minutes = parseInt(localStorage.getItem(STORAGE_TIMER_KEY) || '5');
        localStorage.setItem(STORAGE_AUTO_KEY, 'true');
        if (autoOpenTimer) { clearInterval(autoOpenTimer); autoOpenTimer = null; }
        autoOpenTimer = setInterval(() => { if (!isRunning) openNewTickets(); }, minutes * 60 * 1000);
        updateAutoBtn(true);
        updateListStatus(`🔄 Auto every ${minutes} min`);
    }

    function stopAutoOpen() {
        localStorage.removeItem(STORAGE_AUTO_KEY);
        if (autoOpenTimer) { clearInterval(autoOpenTimer); autoOpenTimer = null; }
        updateAutoBtn(false);
        updateListStatus('Auto stopped');
    }

    function startAutoReload() {
        const minutes = parseInt(localStorage.getItem(STORAGE_RELOAD_KEY) || '3');
        localStorage.setItem('crm_auto_reload_on', 'true');
        if (autoReloadTimer) { clearInterval(autoReloadTimer); autoReloadTimer = null; }
        autoReloadTimer = setInterval(async () => {
            if (!isRunning) {
                updateListStatus('🔄 Updating data...');
                clickUpdateData();
                await wait(1500);
                await openNewTickets();
                updateListStatus(`🔄 Reload every ${minutes} min`);
            }
        }, minutes * 60 * 1000);
        updateReloadBtn(true);
        updateListStatus(`🔄 Reload every ${minutes} min`);
    }

    function stopAutoReload() {
        localStorage.removeItem('crm_auto_reload_on');
        if (autoReloadTimer) { clearInterval(autoReloadTimer); autoReloadTimer = null; }
        updateReloadBtn(false);
        updateListStatus('Reload stopped');
    }

    function setListBtnsDisabled(disabled) {
        ['open-new-btn', 'open-all-btn'].forEach(id => {
            const btn = document.getElementById(id);
            if (btn) btn.disabled = disabled;
        });
    }

    function updateListStatus(text) {
        const el = document.getElementById('open-tickets-status');
        if (el) el.innerText = text;
    }

    function updateAutoBtn(active) {
        const btn = document.getElementById('auto-open-btn');
        if (!btn) return;
        btn.innerText = active ? '🟢 Auto ON' : '⚪ Auto OFF';
        btn.style.background = active ? '#00b894' : '#636e72';
    }

    function updateReloadBtn(active) {
        const btn = document.getElementById('auto-reload-btn');
        if (!btn) return;
        btn.innerText = active ? '🔄 Reload ON' : '🔄 Reload OFF';
        btn.style.background = active ? '#0984e3' : '#636e72';
    }

    function toggleListPanel() {
        const inner = document.getElementById('open-tickets-inner');
        const btn = document.getElementById('panel-toggle-btn');
        if (!inner || !btn) return;
        const hidden = inner.style.display === 'none';
        inner.style.display = hidden ? 'flex' : 'none';
        btn.innerText = hidden ? '🔼 Hide' : '🔽 Tools';
    }

    function initListUI() {
        if (document.getElementById('crm-open-tickets-ui')) return;
        if (!location.href.includes('/tickets') || location.href.match(/\/tickets\/\d+/)) return;

        const container = document.createElement('div');
        container.id = 'crm-open-tickets-ui';
        container.style.cssText = `position:fixed;bottom:30px;right:20px;z-index:9999;display:flex;flex-direction:column;align-items:flex-end;gap:6px;`;

        const toggleBtn = document.createElement('button');
        toggleBtn.id = 'panel-toggle-btn';
        toggleBtn.innerText = '🔼 Hide';
        toggleBtn.style.cssText = `padding:4px 10px;background:#2d3436;color:#b2bec3;border:none;border-radius:6px;font-size:11px;cursor:pointer;`;
        toggleBtn.onclick = toggleListPanel;
        container.appendChild(toggleBtn);

        const inner = document.createElement('div');
        inner.id = 'open-tickets-inner';
        inner.style.cssText = `display:flex;flex-direction:column;align-items:stretch;gap:6px;background:#1e272e;padding:10px;border-radius:10px;box-shadow:0 4px 12px rgba(0,0,0,0.4);min-width:200px;`;

        const status = document.createElement('div');
        status.id = 'open-tickets-status';
        status.innerText = 'Ready';
        status.style.cssText = `color:#b2bec3;font-size:11px;text-align:center;`;
        inner.appendChild(status);

        const makeBtn = (id, text, bg, onclick) => {
            const btn = document.createElement('button');
            btn.id = id; btn.innerText = text;
            btn.style.cssText = `padding:8px 14px;background:${bg};color:#fff;border:none;border-radius:8px;font-size:12px;font-weight:bold;cursor:pointer;`;
            btn.onclick = onclick;
            return btn;
        };

        inner.appendChild(makeBtn('open-new-btn', '📂 Open New Tickets', '#6c5ce7', openNewTickets));
        inner.appendChild(makeBtn('open-all-btn', '📂 Open All Tickets', '#0984e3', openAllTickets));
        inner.appendChild(makeBtn('close-dupes-btn', '🗂 Close Duplicates', '#d63031', closeDuplicateTabs));
        inner.appendChild(makeBtn('bulk-handover-btn', '⚡ Bulk Handover', '#e17055', bulkHandover));

        const sep1 = document.createElement('div');
        sep1.style.cssText = 'height:1px;background:#2d3436;margin:2px 0;';
        inner.appendChild(sep1);

        // Search open tabs
        const searchRow = document.createElement('div');
        searchRow.style.cssText = 'display:flex;gap:6px;';
        const searchInput = document.createElement('input');
        searchInput.id = 'tab-search-input';
        searchInput.placeholder = '🔍 Search open tabs...';
        searchInput.style.cssText = `flex:1;padding:5px 8px;background:#2d3436;color:#fff;border:1px solid #636e72;border-radius:6px;font-size:11px;`;
        searchInput.oninput = () => searchOpenTabs(searchInput.value);
        searchRow.appendChild(searchInput);
        inner.appendChild(searchRow);

        const searchResults = document.createElement('div');
        searchResults.id = 'tab-search-results';
        searchResults.style.cssText = `display:none;flex-direction:column;gap:3px;max-height:120px;overflow-y:auto;`;
        inner.appendChild(searchResults);

        const sep2 = document.createElement('div');
        sep2.style.cssText = 'height:1px;background:#2d3436;margin:2px 0;';
        inner.appendChild(sep2);

        // Auto open timer
        const makeTimerRow = (label, storageKey, inputId) => {
            const row = document.createElement('div');
            row.style.cssText = 'display:flex;align-items:center;gap:6px;';
            const lbl = document.createElement('span');
            lbl.innerText = label;
            lbl.style.cssText = 'color:#b2bec3;font-size:11px;white-space:nowrap;';
            const inp = document.createElement('input');
            inp.id = inputId; inp.type = 'number'; inp.min = '1'; inp.max = '60';
            inp.value = localStorage.getItem(storageKey) || '5';
            inp.style.cssText = `width:45px;padding:4px 6px;background:#2d3436;color:#fff;border:1px solid #636e72;border-radius:4px;font-size:12px;`;
            inp.onchange = () => {
                localStorage.setItem(storageKey, inp.value);
                if (storageKey === STORAGE_TIMER_KEY && localStorage.getItem(STORAGE_AUTO_KEY) === 'true') startAutoOpen();
                if (storageKey === STORAGE_RELOAD_KEY && localStorage.getItem('crm_auto_reload_on') === 'true') startAutoReload();
            };
            row.appendChild(lbl); row.appendChild(inp);
            return row;
        };

        inner.appendChild(makeTimerRow('⏱ open (min):', STORAGE_TIMER_KEY, 'auto-open-input'));
        inner.appendChild(makeBtn('auto-open-btn', '⚪ Auto OFF', '#636e72', () => {
            localStorage.getItem(STORAGE_AUTO_KEY) === 'true' ? stopAutoOpen() : startAutoOpen();
        }));

        inner.appendChild(makeTimerRow('🔄 reload (min):', STORAGE_RELOAD_KEY, 'auto-reload-input'));
        inner.appendChild(makeBtn('auto-reload-btn', '🔄 Reload OFF', '#636e72', () => {
            localStorage.getItem('crm_auto_reload_on') === 'true' ? stopAutoReload() : startAutoReload();
        }));

        container.appendChild(inner);
        document.body.appendChild(container);

        if (localStorage.getItem(STORAGE_AUTO_KEY) === 'true') startAutoOpen();
        if (localStorage.getItem('crm_auto_reload_on') === 'true') startAutoReload();
    }

    // Search open ticket tabs
    function searchOpenTabs(query) {
        const results = document.getElementById('tab-search-results');
        if (!results) return;
        if (!query.trim()) { results.style.display = 'none'; results.innerHTML = ''; return; }
        try {
            chrome.runtime.sendMessage({ type: 'search_tabs', query }, (res) => {
                if (chrome.runtime.lastError || !res?.tabs?.length) {
                    results.style.display = 'none'; results.innerHTML = ''; return;
                }
                results.innerHTML = '';
                results.style.display = 'flex';
                res.tabs.forEach(tab => {
                    const item = document.createElement('div');
                    item.style.cssText = `padding:5px 8px;background:#2d3436;border-radius:5px;font-size:11px;color:#dfe6e9;cursor:pointer;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;`;
                    item.innerText = tab.title || tab.url;
                    item.title = tab.url;
                    item.onclick = () => chrome.runtime.sendMessage({ type: 'focus_tab', tabId: tab.id });
                    results.appendChild(item);
                });
            });
        } catch(e) {}
    }

    // ─────────────────────────────────────────
    // TICKET PAGE UI — Sidebar
    // ─────────────────────────────────────────
    const PROLONG_REASONS = [
        { label: 'TPP', testid: 'select_option_tpp', color: '#6c5ce7' },
        { label: 'Client', testid: 'select_option_client', color: '#0984e3' },
        { label: 'Hotel', testid: 'select_option_hotel', color: '#00b894' },
        { label: 'Technical problem', testid: 'select_option_technical_problem', color: '#e17055' },
    ];

    function getStorageKey() { return 'autoprolong_active_' + location.pathname; }
    function getReasonKey() { return 'autoprolong_reason_' + location.pathname; }
    function getNotesKey() { return 'crm_notes_' + location.pathname; }
    function getSavedReason() { return localStorage.getItem(getReasonKey()) || 'select_option_tpp'; }

    // Prolongation counter
    function getProlongCount() { return parseInt(localStorage.getItem('prolong_count_' + location.pathname) || '0'); }
    function incProlongCount() {
        const count = getProlongCount() + 1;
        localStorage.setItem('prolong_count_' + location.pathname, count);
        updateProlongCounter(count);
    }
    function updateProlongCounter(count) {
        const el = document.getElementById('prolong-counter');
        if (el) el.innerText = `🔢 Prolonged: ${count}x`;
    }

    // Estimated time countdown
    function startCountdown() {
        const countdownEl = document.getElementById('prolong-countdown');
        if (!countdownEl) return;
        setInterval(() => {
            const estimatedEl = document.querySelector('[class*="estimated"], [data-testid*="estimated"]');
            const prolongBtn = document.querySelector('button[class*="primary"]');
            const btnText = [...document.querySelectorAll('button')].find(b => b.innerText?.trim() === 'Prolongation');
            if (btnText) {
                countdownEl.innerText = '⏱ Prolongation available!';
                countdownEl.style.color = '#00b894';
            } else {
                countdownEl.innerText = '⏱ Waiting for timer...';
                countdownEl.style.color = '#636e72';
            }
        }, 2000);
    }

    function initTicketUI() {
        if (document.getElementById('crm-sidebar')) return;
        if (!location.href.match(/\/tickets\/\d+/)) return;

        const myId = location.href.match(/\/tickets\/(\d+)/)?.[1];
        if (myId) {
            channel.onmessage = (e) => {
                if (e.data.type === 'ping') channel.postMessage({ type: 'pong', id: myId });
                if (e.data.type === 'bulk_handover') runHandover();
            };
        }

        // ── Sidebar container ──
        const sidebar = document.createElement('div');
        sidebar.id = 'crm-sidebar';
        sidebar.style.cssText = `
            position: fixed;
            top: 0; right: 0;
            width: 0;
            height: 100vh;
            z-index: 9998;
            transition: width 0.25s ease;
            pointer-events: none;
        `;

        // ── Panel inside sidebar ──
        const panel = document.createElement('div');
        panel.id = 'crm-tools-ui';
        panel.style.cssText = `
            position: absolute;
            top: 0; right: 0;
            width: 210px;
            height: 100%;
            background: #131920;
            border-left: 1px solid #1e2330;
            box-shadow: -4px 0 20px rgba(0,0,0,0.4);
            display: flex;
            flex-direction: column;
            overflow-y: auto;
            transform: translateX(100%);
            transition: transform 0.25s ease;
            pointer-events: all;
            padding-bottom: 20px;
        `;

        // ── Toggle tab (always visible) ──
        const toggleTab = document.createElement('div');
        toggleTab.id = 'crm-sidebar-tab';
        toggleTab.style.cssText = `
            position: fixed;
            top: 50%;
            right: 0;
            transform: translateY(-50%);
            z-index: 9999;
            background: #6c5ce7;
            color: #fff;
            padding: 12px 5px;
            border-radius: 8px 0 0 8px;
            cursor: pointer;
            font-size: 10px;
            font-weight: 900;
            writing-mode: vertical-rl;
            text-orientation: mixed;
            letter-spacing: 0.1em;
            box-shadow: -2px 0 10px rgba(108,92,231,0.4);
            transition: right 0.25s ease, background 0.2s;
            user-select: none;
        `;
        toggleTab.innerText = 'CRM TOOLS';
        toggleTab.onclick = toggleSidebar;
        document.body.appendChild(toggleTab);

        let sidebarOpen = false;
        function toggleSidebar() {
            sidebarOpen = !sidebarOpen;
            panel.style.transform = sidebarOpen ? 'translateX(0)' : 'translateX(100%)';
            toggleTab.style.right = sidebarOpen ? '210px' : '0';
            toggleTab.style.background = sidebarOpen ? '#5a4bd1' : '#6c5ce7';
        }

        // ── Panel header ──
        const header = document.createElement('div');
        header.style.cssText = `padding:16px 14px 10px;border-bottom:1px solid #1e2330;display:flex;align-items:center;justify-content:space-between;`;
        const headerTitle = document.createElement('div');
        headerTitle.style.cssText = `font-size:11px;font-weight:900;color:#6c5ce7;letter-spacing:0.15em;text-transform:uppercase;font-family:monospace;`;
        headerTitle.innerText = 'CRM Tools';
        const closeBtn = document.createElement('button');
        closeBtn.innerText = '✕';
        closeBtn.style.cssText = `background:none;border:none;color:#636e72;cursor:pointer;font-size:14px;padding:0;`;
        closeBtn.onclick = toggleSidebar;
        header.appendChild(headerTitle);
        header.appendChild(closeBtn);
        panel.appendChild(header);

        const body = document.createElement('div');
        body.style.cssText = `padding:12px;display:flex;flex-direction:column;gap:10px;`;

        // Helper: section label
        const makeLabel = (text) => {
            const el = document.createElement('div');
            el.style.cssText = `font-size:9px;font-weight:700;letter-spacing:0.15em;text-transform:uppercase;color:#636e72;margin-top:4px;`;
            el.innerText = text;
            return el;
        };

        // Helper: button
        const makeBtn = (id, text, bg, onclick) => {
            const btn = document.createElement('button');
            btn.id = id; btn.innerText = text;
            btn.style.cssText = `padding:8px;background:${bg};color:#fff;border:none;border-radius:8px;font-size:12px;font-weight:bold;cursor:pointer;width:100%;text-align:left;`;
            btn.onclick = onclick;
            return btn;
        };

        // ── HANDOVER ──
        body.appendChild(makeLabel('Handover'));
        body.appendChild(makeBtn('handover-btn', '🔁 Handover', '#6c5ce7', runHandover));

        // ── PROLONG REASON ──
        body.appendChild(makeLabel('Prolong Reason'));
        const reasonGrid = document.createElement('div');
        reasonGrid.id = 'prolong-reason-grid';
        reasonGrid.style.cssText = 'display:grid;grid-template-columns:1fr 1fr;gap:4px;';

        function setActiveReason(testid) {
            localStorage.setItem(getReasonKey(), testid);
            reasonGrid.querySelectorAll('button').forEach(b => {
                const isActive = b.dataset.testid === testid;
                b.style.opacity = isActive ? '1' : '0.3';
                b.style.transform = isActive ? 'scale(1.04)' : 'scale(1)';
                b.style.boxShadow = isActive ? `0 0 8px ${b.dataset.color}88` : 'none';
            });
        }

        PROLONG_REASONS.forEach(r => {
            const btn = document.createElement('button');
            btn.dataset.testid = r.testid;
            btn.dataset.color = r.color;
            btn.innerText = r.label;
            btn.style.cssText = `padding:6px 4px;background:${r.color};color:#fff;border:none;border-radius:6px;font-size:10px;font-weight:700;cursor:pointer;transition:all 0.15s;opacity:0.3;`;
            btn.onclick = () => setActiveReason(r.testid);
            reasonGrid.appendChild(btn);
        });
        body.appendChild(reasonGrid);
        setActiveReason(getSavedReason());

        // ── AUTOPROLONG ──
        body.appendChild(makeLabel('Auto Prolongation'));

        const countdown = document.createElement('div');
        countdown.id = 'prolong-countdown';
        countdown.style.cssText = `font-size:10px;color:#636e72;margin-bottom:2px;`;
        countdown.innerText = '⏱ Waiting for timer...';
        body.appendChild(countdown);

        const prolongCounter = document.createElement('div');
        prolongCounter.id = 'prolong-counter';
        prolongCounter.style.cssText = `font-size:10px;color:#b2bec3;margin-bottom:4px;`;
        prolongCounter.innerText = `🔢 Prolonged: ${getProlongCount()}x`;
        body.appendChild(prolongCounter);

        const toggleBtn = document.createElement('button');
        toggleBtn.id = 'autoprolong-toggle';
        toggleBtn.innerText = active ? '🟢 AutoProlong ON' : '⚪ AutoProlong OFF';
        toggleBtn.style.cssText = `padding:8px;background:${active ? '#00b894' : '#636e72'};color:#fff;border:none;border-radius:8px;font-size:12px;font-weight:bold;cursor:pointer;width:100%;`;
        toggleBtn.onclick = () => active ? stopMonitoring() : startMonitoring();
        body.appendChild(toggleBtn);

        const statusEl = document.createElement('div');
        statusEl.id = 'autoprolong-status';
        statusEl.innerText = active ? '👀 Waiting...' : '⏸ Disabled';
        statusEl.style.cssText = `padding:5px 8px;background:${active ? '#6c5ce7' : '#636e72'};color:#fff;border-radius:6px;font-size:11px;font-weight:bold;text-align:center;`;
        body.appendChild(statusEl);

        // ── PRIORITY COLOR ──
        body.appendChild(makeLabel('Priority Indicator'));
        const priorityStatus = document.createElement('div');
        priorityStatus.id = 'priority-indicator';
        priorityStatus.style.cssText = `font-size:10px;color:#b2bec3;padding:4px 0;`;
        priorityStatus.innerText = 'Detecting...';
        body.appendChild(priorityStatus);

        // ── QUICK NOTES ──
        body.appendChild(makeLabel('Quick Notes'));
        const notesArea = document.createElement('textarea');
        notesArea.id = 'crm-notes';
        notesArea.placeholder = 'Notes for this ticket...';
        notesArea.value = localStorage.getItem(getNotesKey()) || '';
        notesArea.style.cssText = `width:100%;height:80px;background:#1e272e;color:#dfe6e9;border:1px solid #2d3436;border-radius:6px;padding:6px 8px;font-size:11px;resize:none;font-family:monospace;line-height:1.5;`;
        notesArea.oninput = () => localStorage.setItem(getNotesKey(), notesArea.value);
        body.appendChild(notesArea);

        // Clear notes
        const clearNotes = document.createElement('button');
        clearNotes.innerText = '🗑 Clear notes';
        clearNotes.style.cssText = `padding:5px 8px;background:#2d3436;color:#b2bec3;border:none;border-radius:6px;font-size:10px;cursor:pointer;width:100%;`;
        clearNotes.onclick = () => { notesArea.value = ''; localStorage.removeItem(getNotesKey()); };
        body.appendChild(clearNotes);

        // ── SCHEDULED HANDOVER ──
        body.appendChild(makeLabel('Scheduled Handover'));
        const schedRow = document.createElement('div');
        schedRow.style.cssText = 'display:flex;gap:6px;align-items:center;';
        const schedInput = document.createElement('input');
        schedInput.type = 'time';
        schedInput.id = 'handover-time-input';
        schedInput.value = localStorage.getItem('handover_scheduled_time') || '';
        schedInput.style.cssText = `flex:1;padding:5px;background:#1e272e;color:#fff;border:1px solid #2d3436;border-radius:6px;font-size:11px;`;
        schedInput.onchange = () => {
            localStorage.setItem('handover_scheduled_time', schedInput.value);
            scheduleHandover(schedInput.value);
        };
        schedRow.appendChild(schedInput);
        body.appendChild(schedRow);

        const schedStatus = document.createElement('div');
        schedStatus.id = 'handover-sched-status';
        schedStatus.style.cssText = `font-size:10px;color:#636e72;`;
        schedStatus.innerText = schedInput.value ? `⏰ Scheduled at ${schedInput.value}` : 'No schedule set';
        body.appendChild(schedStatus);

        panel.appendChild(body);
        sidebar.appendChild(panel);
        document.body.appendChild(sidebar);

        // Init features
        startCountdown();
        detectPriority();
        if (localStorage.getItem(getStorageKey()) === 'true') startMonitoring();
        if (schedInput.value) scheduleHandover(schedInput.value);
    }

    // Priority detection
    function detectPriority() {
        const el = document.getElementById('priority-indicator');
        if (!el) return;
        setInterval(() => {
            const priorityEl = [...document.querySelectorAll('div, span')]
                .find(e => e.children.length === 0 && ['Urgent', 'High', 'Normal', 'Low'].includes(e.innerText?.trim()));
            if (priorityEl) {
                const p = priorityEl.innerText.trim();
                const colors = { Urgent: '#d63031', High: '#e17055', Normal: '#fdcb6e', Low: '#00b894' };
                const emojis = { Urgent: '🔴', High: '🟠', Normal: '🟡', Low: '🟢' };
                el.innerText = `${emojis[p] || '⚪'} ${p}`;
                el.style.color = colors[p] || '#b2bec3';
                // Update tab title prefix
                if (!document.title.startsWith(emojis[p])) {
                    const clean = document.title.replace(/^[🔴🟠🟡🟢⚪]\s/, '');
                    if (!titleFlashTimer) document.title = `${emojis[p]} ${clean}`;
                }
            }
        }, 3000);
    }

    // Scheduled handover
    let handoverScheduleTimer = null;
    function scheduleHandover(timeStr) {
        if (handoverScheduleTimer) { clearInterval(handoverScheduleTimer); handoverScheduleTimer = null; }
        if (!timeStr) return;
        const el = document.getElementById('handover-sched-status');
        handoverScheduleTimer = setInterval(() => {
            const now = new Date();
            const [h, m] = timeStr.split(':').map(Number);
            if (now.getHours() === h && now.getMinutes() === m) {
                runHandover();
                if (el) el.innerText = `✅ Handover done at ${timeStr}`;
                clearInterval(handoverScheduleTimer);
            }
        }, 30000);
        if (el) el.innerText = `⏰ Scheduled at ${timeStr}`;
    }

    // ─── HANDOVER ───
    function clickEdit() {
        document.querySelector('svg[data-icon="pen"]')?.closest('button')?.click();
    }

    function fireClick(el) {
        ['mouseover','mousedown','mouseup','click'].forEach(t =>
            el.dispatchEvent(new MouseEvent(t, { bubbles: true })));
    }

    function typeInto(input, text) {
        const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
        setter?.call(input, text);
        input.dispatchEvent(new Event('input', { bubbles: true }));
    }

    async function waitForElement(selector, timeout = 5000) {
        const start = Date.now();
        while (Date.now() - start < timeout) {
            const el = document.querySelector(selector);
            if (el) return el;
            await wait(100);
        }
        return null;
    }

    async function setReactSelect(inputTestId, searchText, optionTestId) {
        const input = document.querySelector(`[data-testid="${inputTestId}"]`);
        if (!input) return false;
        input.focus(); input.click();
        await wait(150);
        typeInto(input, searchText);
        const option = await waitForElement(`[data-testid="${optionTestId}"]`);
        if (!option) return false;
        fireClick(option);
        return true;
    }

    async function waitForSave() {
        const start = Date.now();
        while (Date.now() - start < 5000) {
            const btn = [...document.querySelectorAll('button')].find(b => b.innerText?.trim().toLowerCase() === 'save');
            if (btn) { btn.click(); return; }
            await wait(100);
        }
    }

    async function runHandover() {
        const btn = document.getElementById('handover-btn');
        if (btn) { btn.disabled = true; btn.innerText = '⏳ Handover...'; }
        clickEdit();
        await wait(800);
        await setReactSelect('select_input_owner', 'CRM', 'select_option_crm_bot');
        await wait(300);
        await setReactSelect('select_input_pool', 'inc', 'select_option_incidents_handover_day');
        await wait(300);
        await waitForSave();
        if (btn) { btn.disabled = false; btn.innerText = '🔁 Handover'; }
    }

    // ─── AUTO PROLONGATION ───
    const CHECK_MS = 5000;
    const RELOAD_MS = 5 * 60 * 1000;

    let running = false;
    let active = false;
    let checkTimer = null;
    let reloadTimer = null;
    let titleFlashTimer = null;
    const originalTitle = document.title;

    function startTitleFlash() {
        if (titleFlashTimer) return;
        let state = false;
        titleFlashTimer = setInterval(() => {
            document.title = state ? '⏱ AutoProlong ON' : (originalTitle || 'CRM');
            state = !state;
        }, 1200);
    }

    function stopTitleFlash() {
        if (titleFlashTimer) { clearInterval(titleFlashTimer); titleFlashTimer = null; }
        document.title = originalTitle || 'CRM';
    }

    function findProlongationBtn() {
        return [...document.querySelectorAll('button')]
            .find(b => b.innerText?.trim() === 'Prolongation' && !b.disabled);
    }

    async function handleProlongation() {
        const alreadyOpen = document.querySelector('[data-testid="select_input_prolongation_reason"]');
        if (!alreadyOpen) {
            const btn = findProlongationBtn();
            if (!btn) return false;
            btn.click();
            await wait(1000);
        }
        let input = null;
        for (let i = 0; i < 10; i++) {
            input = document.querySelector('[data-testid="select_input_prolongation_reason"]');
            if (input) break;
            await wait(200);
        }
        if (!input) return false;

        input.focus(); input.click();
        await wait(300);
        const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
        const reasonTestId = getSavedReason();
        const reasonObj = PROLONG_REASONS.find(r => r.testid === reasonTestId);
        const reasonLabel = reasonObj?.label || 'TPP';

        setter?.call(input, reasonLabel);
        input.dispatchEvent(new Event('input', { bubbles: true }));
        await wait(800);

        for (let i = 0; i < 10; i++) {
            const option = document.querySelector(`[data-testid="${reasonTestId}"]`);
            if (option) {
                ['mousedown','mouseup','click'].forEach(t =>
                    option.dispatchEvent(new MouseEvent(t, { bubbles: true })));
                break;
            }
            await wait(200);
        }
        await wait(400);

        for (let i = 0; i < 10; i++) {
            const saveBtn = [...document.querySelectorAll('button')]
                .find(b => b.innerText?.trim() === 'Save' && !b.disabled);
            if (saveBtn) {
                saveBtn.click();
                incProlongCount();
                showProlongNotification(reasonLabel);
                await wait(1500);
                location.reload();
                return true;
            }
            await wait(200);
        }
        return false;
    }

    async function tick() {
        if (!active || running) return;
        const btn = findProlongationBtn();
        const modalOpen = document.querySelector('[data-testid="select_input_prolongation_reason"]');
        if (btn || modalOpen) {
            running = true;
            updateProlongStatus('🔄 Prolonging...', '#fdcb6e');
            const ok = await handleProlongation();
            updateProlongStatus(ok ? '✅ Done!' : '⚠️ Error', ok ? '#00b894' : '#d63031');
            setTimeout(() => updateProlongStatus('👀 Waiting...'), 3000);
            running = false;
        } else {
            updateProlongStatus('👀 Waiting...');
        }
    }

    function startMonitoring() {
        active = true;
        localStorage.setItem(getStorageKey(), 'true');
        updateToggleBtn();
        tick();
        checkTimer = setInterval(tick, CHECK_MS);
        reloadTimer = setInterval(() => { if (!running) location.reload(); }, RELOAD_MS);
        updateProlongStatus('👀 Waiting...');
        startTitleFlash();
    }

    function stopMonitoring() {
        active = false;
        localStorage.removeItem(getStorageKey());
        clearInterval(checkTimer);
        clearInterval(reloadTimer);
        updateToggleBtn();
        updateProlongStatus('⏸ Disabled', '#636e72');
        stopTitleFlash();
    }

    function updateToggleBtn() {
        const btn = document.getElementById('autoprolong-toggle');
        if (!btn) return;
        btn.innerText = active ? '🟢 AutoProlong ON' : '⚪ AutoProlong OFF';
        btn.style.background = active ? '#00b894' : '#636e72';
    }

    function updateProlongStatus(text, color = '#6c5ce7') {
        const el = document.getElementById('autoprolong-status');
        if (el) { el.innerText = text; el.style.background = color; }
    }

    function showProlongNotification(reason) {
        const toast = document.createElement('div');
        toast.innerText = `✅ Prolongation done! (${reason})`;
        toast.style.cssText = `position:fixed;bottom:30px;left:50%;transform:translateX(-50%);z-index:99999;padding:12px 20px;background:#00b894;color:#fff;border-radius:8px;font-size:14px;font-weight:bold;box-shadow:0 2px 8px rgba(0,0,0,0.3);transition:opacity 0.5s;`;
        document.body.appendChild(toast);
        setTimeout(() => { toast.style.opacity = '0'; }, 3000);
        setTimeout(() => { toast.remove(); }, 3500);

        if (titleFlashTimer) { clearInterval(titleFlashTimer); titleFlashTimer = null; }
        let successState = false;
        const successTimer = setInterval(() => {
            document.title = successState ? `✅ Prolonged! (${reason})` : '⏱ AutoProlong ON';
            successState = !successState;
        }, 400);
        setTimeout(() => {
            clearInterval(successTimer);
            if (active) startTitleFlash();
        }, 5000);
    }

    // Chrome system notification on prolong
    function sendSystemNotification(reason) {
        if (!('Notification' in window)) return;
        if (Notification.permission === 'granted') {
            new Notification('✅ Prolongation done!', {
                body: `Reason: ${reason} · Ticket ${location.pathname}`,
                icon: 'https://crm.etg.team/favicon.ico'
            });
        } else if (Notification.permission !== 'denied') {
            Notification.requestPermission().then(p => {
                if (p === 'granted') sendSystemNotification(reason);
            });
        }
    }

})();
