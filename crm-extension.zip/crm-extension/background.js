chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

    if (msg.type === 'open_tabs_background') {
        const urls = msg.urls;
        let opened = 0;
        const openNext = (index) => {
            if (index >= urls.length) { sendResponse({ opened }); return; }
            chrome.tabs.create({ url: urls[index], active: false }, () => { opened++; openNext(index + 1); });
        };
        openNext(0);
        return true;
    }

    if (msg.type === 'close_duplicate_tabs') {
        chrome.tabs.query({ url: 'https://crm.etg.team/tickets/*' }, (tabs) => {
            const seen = new Map();
            const toClose = [];
            tabs.forEach(tab => {
                const match = tab.url.match(/\/tickets\/(\d+)\//);
                if (!match) return;
                const ticketId = match[1];
                if (seen.has(ticketId)) toClose.push(tab.id);
                else seen.set(ticketId, tab.id);
            });
            if (toClose.length === 0) { sendResponse({ closed: 0 }); return; }
            chrome.tabs.remove(toClose, () => sendResponse({ closed: toClose.length }));
        });
        return true;
    }

    if (msg.type === 'search_tabs') {
        const query = (msg.query || '').toLowerCase();
        chrome.tabs.query({ url: 'https://crm.etg.team/tickets/*' }, (tabs) => {
            const matched = tabs.filter(t =>
                t.url?.toLowerCase().includes(query) ||
                t.title?.toLowerCase().includes(query)
            ).slice(0, 8).map(t => ({ id: t.id, title: t.title, url: t.url }));
            sendResponse({ tabs: matched });
        });
        return true;
    }

    if (msg.type === 'focus_tab') {
        chrome.tabs.get(msg.tabId, (tab) => {
            if (tab) {
                chrome.tabs.update(msg.tabId, { active: true });
                chrome.windows.update(tab.windowId, { focused: true });
            }
        });
        return false;
    }
});
