// CRM ETG Tools — Background Service Worker v3.2

function safeSendToTab(tabId, msg, callback) {
    chrome.tabs.sendMessage(tabId, msg, (res) => {
        if (chrome.runtime.lastError) {
            // Tab not ready or no content script — silently skip
            if (callback) callback(null);
            return;
        }
        if (callback) callback(res);
    });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

    if (msg.type === 'open_tabs_background') {
        const urls = msg.urls || [];
        if (urls.length === 0) { sendResponse({ opened: 0 }); return true; }
        let opened = 0;
        const openNext = (index) => {
            if (index >= urls.length) { sendResponse({ opened }); return; }
            chrome.tabs.create({ url: urls[index], active: false }, () => { opened++; openNext(index + 1); });
        };
        openNext(0);
        return true;
    }

    if (msg.type === 'close_duplicate_tabs') {
        chrome.tabs.query({ url: 'https://crm.etg.team/tickets/*' }, (tabs) => {
            const seen = new Map();
            const toClose = [];
            tabs.forEach(tab => {
                const match = tab.url.match(/\/tickets\/(\d+)\//);
                if (!match) return;
                const id = match[1];
                if (seen.has(id)) toClose.push(tab.id);
                else seen.set(id, tab.id);
            });
            if (toClose.length === 0) { sendResponse({ closed: 0 }); return; }
            chrome.tabs.remove(toClose, () => sendResponse({ closed: toClose.length }));
        });
        return true;
    }

    if (msg.type === 'search_tabs') {
        const query = (msg.query || '').toLowerCase().trim();
        chrome.tabs.query({ url: 'https://crm.etg.team/tickets/*' }, (tabs) => {
            const ticketTabs = tabs.filter(t => /\/tickets\/\d+\//.test(t.url));
            if (!ticketTabs.length) { sendResponse({ tabs: [] }); return; }

            let pending = ticketTabs.length;
            const results = [];
            let responded = false;

            const tryRespond = () => {
                if (responded) return;
                responded = true;
                sendResponse({ tabs: results.slice(0, 10) });
            };

            // Safety timeout
            const timeout = setTimeout(tryRespond, 2500);

            ticketTabs.forEach(tab => {
                safeSendToTab(tab.id, { type: 'get_ticket_data' }, (data) => {
                    const ticketId = tab.url.match(/\/tickets\/(\d+)\//)?.[1] || '';
                    const searchable = [
                        ticketId, tab.title || '',
                        data?.guests || '', data?.client || '',
                        data?.hotel || '', data?.owner || '',
                        data?.status || '',
                    ].join(' ').toLowerCase();

                    if (searchable.includes(query)) {
                        results.push({
                            id: tab.id, title: tab.title, url: tab.url,
                            ticketId,
                            guests: data?.guests || '',
                            hotel: data?.hotel?.split('\n')[0] || '',
                            status: data?.status || '',
                        });
                    }
                    pending--;
                    if (pending === 0) { clearTimeout(timeout); tryRespond(); }
                });
            });
        });
        return true;
    }

    if (msg.type === 'get_all_ticket_statuses') {
        chrome.tabs.query({ url: 'https://crm.etg.team/tickets/*' }, (tabs) => {
            const ticketTabs = tabs.filter(t => /\/tickets\/\d+\//.test(t.url));
            if (!ticketTabs.length) { sendResponse({ statuses: [] }); return; }

            let pending = ticketTabs.length;
            const statuses = [];
            let responded = false;

            const tryRespond = () => {
                if (responded) return;
                responded = true;
                sendResponse({ statuses });
            };

            const timeout = setTimeout(tryRespond, 2000);

            ticketTabs.forEach(tab => {
                safeSendToTab(tab.id, { type: 'get_ticket_data' }, (data) => {
                    const id = tab.url.match(/\/tickets\/(\d+)\//)?.[1];
                    if (id && data?.status) statuses.push({ id, status: data.status });
                    pending--;
                    if (pending === 0) { clearTimeout(timeout); tryRespond(); }
                });
            });
        });
        return true;
    }

    if (msg.type === 'focus_tab') {
        chrome.tabs.get(msg.tabId, (tab) => {
            if (chrome.runtime.lastError || !tab) return;
            chrome.tabs.update(msg.tabId, { active: true });
            chrome.windows.update(tab.windowId, { focused: true });
        });
        return false;
    }

    if (msg.type === 'reload_current_tab') {
        if (sender.tab?.id) chrome.tabs.reload(sender.tab.id);
        return false;
    }

    if (msg.type === 'close_current_tab') {
        if (sender.tab?.id) chrome.tabs.remove(sender.tab.id);
        return false;
    }
});
