// CRM ETG Tools — Background Service Worker

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

    // Open tabs in background without stealing focus
    if (msg.type === 'open_tabs_background') {
        const urls = msg.urls || [];
        if (urls.length === 0) { sendResponse({ opened: 0 }); return true; }
        let opened = 0;
        const openNext = (index) => {
            if (index >= urls.length) { sendResponse({ opened }); return; }
            chrome.tabs.create({ url: urls[index], active: false }, () => {
                opened++;
                openNext(index + 1);
            });
        };
        openNext(0);
        return true; // async
    }

    // Close duplicate ticket tabs — keep first, close rest
    if (msg.type === 'close_duplicate_tabs') {
        chrome.tabs.query({ url: 'https://crm.etg.team/tickets/*' }, (tabs) => {
            const seen = new Map();
            const toClose = [];
            tabs.forEach(tab => {
                const match = tab.url.match(/\/tickets\/(\d+)\//);
                if (!match) return;
                const id = match[1];
                if (seen.has(id)) toClose.push(tab.id);
                else seen.set(id, tab.id);
            });
            if (toClose.length === 0) { sendResponse({ closed: 0 }); return; }
            chrome.tabs.remove(toClose, () => sendResponse({ closed: toClose.length }));
        });
        return true; // async
    }

    // Search open ticket tabs by query
    if (msg.type === 'search_tabs') {
        const query = (msg.query || '').toLowerCase();
        chrome.tabs.query({ url: 'https://crm.etg.team/tickets/*' }, (tabs) => {
            const matched = tabs
                .filter(t => t.url?.toLowerCase().includes(query) || t.title?.toLowerCase().includes(query))
                .slice(0, 10)
                .map(t => ({ id: t.id, title: t.title, url: t.url }));
            sendResponse({ tabs: matched });
        });
        return true; // async
    }

    // Focus a specific tab
    if (msg.type === 'focus_tab') {
        chrome.tabs.get(msg.tabId, (tab) => {
            if (chrome.runtime.lastError || !tab) return;
            chrome.tabs.update(msg.tabId, { active: true });
            chrome.windows.update(tab.windowId, { focused: true });
        });
        // No sendResponse needed
        return false;
    }

    // Reload current tab from content script
    if (msg.type === 'reload_current_tab') {
        if (sender.tab?.id) chrome.tabs.reload(sender.tab.id);
        return false;
    }
});
